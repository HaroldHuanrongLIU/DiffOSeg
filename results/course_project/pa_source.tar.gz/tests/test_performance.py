import copy
import unittest
import hashlib
import json
import tempfile
from pathlib import Path

import numpy as np

import torch

from ddpm.polyak import PolyakAverager
from reproduction.performance import ForeachEMA, ContinuousBatchSampler, reference_sample_budget
from reproduction.run import read_checkpoint, sample_experts, inherit_completed_runs, sha256, TRAINING_PROTOCOL, validate_run_protocol


class PerformanceTests(unittest.TestCase):
    def test_foreach_ema_matches_reference_with_integer_buffers(self):
        model = torch.nn.BatchNorm1d(3)
        model.register_buffer("double_buffer", torch.ones(3, dtype=torch.float64))
        reference = PolyakAverager(model, copy.deepcopy(model), 0.9)
        optimized = ForeachEMA(model, copy.deepcopy(model), 0.9)
        for index in range(1, 5):
            with torch.no_grad():
                model.weight.fill_(index / 3)
                model.running_mean.fill_(index)
                model.num_batches_tracked.fill_(index * 17)
            reference.update()
            optimized.update()
        for name, value in reference.average_model.state_dict().items():
            torch.testing.assert_close(optimized.average_model.state_dict()[name], value)

    def test_sample_budget_counts_partial_reference_batches(self):
        self.assertEqual(reference_sample_budget(1159, 12, 120000), 1433815)
        self.assertEqual(reference_sample_budget(10, 4, 5), 18)

    def test_sampler_preserves_budget_and_resume_order(self):
        full = list(ContinuousBatchSampler(10, 8, 35, 7))
        self.assertEqual([len(batch) for batch in full], [8, 8, 8, 8, 3])
        order = [index for batch in full for index in batch]
        for start in (0, 10, 20):
            self.assertEqual(sorted(order[start:start + 10]), list(range(10)))
        resumed = list(ContinuousBatchSampler(10, 8, 35, 7, start=16))
        self.assertEqual(resumed, full[2:])

    def test_checkpoint_source_changes_require_verified_origin(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "final.pt"
            torch.save({"source_id": "old", "config_id": "config", "step": 2,
                        "training_protocol": TRAINING_PROTOCOL}, path)
            with self.assertRaises(ValueError):
                read_checkpoint(path, "new", "config")
            origin = {"source_id": "old", "config_id": "config", "sha256": "wrong"}
            (path.parent / "checkpoint_origin.json").write_text(json.dumps(origin))
            with self.assertRaises(ValueError):
                read_checkpoint(path, "new", "config")
            origin["sha256"] = sha256(path)
            (path.parent / "checkpoint_origin.json").write_text(json.dumps(origin))
            self.assertEqual(read_checkpoint(path, "new", "config")["step"], 2)
            with self.assertRaises(ValueError):
                read_checkpoint(path, "new", "other-config")

    def test_legacy_checkpoint_cannot_bypass_protocol_check_with_valid_origin(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "final.pt"
            for protocol in (None, "fixed_t100"):
                state = {"source_id": "old", "config_id": "config", "step": 2}
                if protocol is not None:
                    state["training_protocol"] = protocol
                torch.save(state, path)
                origin = {"source_id": "old", "config_id": "config", "sha256": sha256(path)}
                (path.parent / "checkpoint_origin.json").write_text(json.dumps(origin))
                with self.subTest(protocol=protocol), self.assertRaisesRegex(ValueError, "protocol"):
                    read_checkpoint(path, "new", "config")

    def test_inheritance_preserves_completed_checkpoint_bytes(self):
        with tempfile.TemporaryDirectory() as temporary:
            previous, output = Path(temporary) / "old", Path(temporary) / "new"
            directory = previous / "lidc/fold_0/stage_1"
            directory.mkdir(parents=True)
            params = {"steps": 2, "batch_size": 12, "classification": "paper_budget_with_documented_assumptions"}
            config_id = hashlib.sha256(json.dumps(params, sort_keys=True).encode()).hexdigest()
            (directory / "config.json").write_text(json.dumps(params))
            torch.save({"source_id": "old", "config_id": config_id, "step": 2,
                        "training_protocol": TRAINING_PROTOCOL}, directory / "final.pt")
            (previous / "environment.json").write_text(json.dumps({"source_id": "old", "training_protocol": TRAINING_PROTOCOL}))
            (previous / "input_hashes.json").write_text(json.dumps({"input": "hash"}))
            inherit_completed_runs(previous, output, {"input": "hash"})
            destination = output / "lidc/fold_0/stage_1/final.pt"
            self.assertEqual(sha256(destination), sha256(directory / "final.pt"))
            self.assertEqual(read_checkpoint(destination, "new", config_id)["step"], 2)
            with self.assertRaises(ValueError):
                inherit_completed_runs(previous, output, {"input": "different"})

    def test_legacy_run_rejected_before_modifying_or_inheriting_artifacts(self):
        with tempfile.TemporaryDirectory() as temporary:
            previous, output = Path(temporary) / "old", Path(temporary) / "new"
            previous.mkdir()
            environment = previous / "environment.json"
            environment.write_text(json.dumps({"source_id": "old"}))
            before = environment.read_bytes()
            with self.assertRaisesRegex(ValueError, "protocol"):
                validate_run_protocol(previous)
            with self.assertRaisesRegex(ValueError, "protocol"):
                inherit_completed_runs(previous, output, {})
            self.assertEqual(environment.read_bytes(), before)
            self.assertFalse(output.exists())
            validate_run_protocol(output)

    def test_batched_experts_keep_identity_across_chunk_boundaries(self):
        class EchoExpert(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.dummy = torch.nn.Parameter(torch.zeros(()))

            def forward(self, noise, condition):
                foreground = condition["txt"].float()[:, None, None].expand(-1, 2, 2) / 3
                return {"diffusion_out": torch.stack((1 - foreground, foreground), dim=1)}

        predictions = sample_experts(EchoExpert(), torch.zeros(1, 2, 2), 5, 7)
        self.assertEqual(predictions.shape, (4, 5, 2, 2))
        for expert in range(4):
            np.testing.assert_allclose(predictions[expert], expert / 3, atol=1e-7)


if __name__ == "__main__":
    unittest.main()
