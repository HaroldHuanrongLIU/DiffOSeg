import copy
import random
import unittest
from unittest.mock import patch

import numpy as np
import torch

from datasets import lidc, npc_170
from ddpm.models.diffusion_denoising import DiffusionModel, DenoisingModel
from ddpm.polyak import PolyakAverager
from ddpm.trainer import Trainer


class TinyUNet(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = torch.nn.Conv2d(2, 2, 1)
        self.timesteps = []

    def forward(self, x, condition, feature_condition=None, timesteps=None):
        self.timesteps.extend(timesteps.tolist())
        return {"diffusion_out": self.conv(x).softmax(1)}


class ReproductionRegressions(unittest.TestCase):
    def setUp(self):
        random.seed(7)
        np.random.seed(7)
        torch.manual_seed(7)
        torch.set_num_threads(1)

    def test_transform_preserves_fractional_consensus(self):
        for module, channels in ((lidc, 1), (npc_170, 3)):
            for probability in (0., 0.25, 0.5, 0.75, 1.):
                with self.subTest(dataset=module.__name__, probability=probability):
                    image = np.zeros((channels, 128, 128), dtype=np.uint8)
                    consensus = np.full((128, 128), probability, dtype=np.float32)
                    with patch.object(npc_170, "random_rotate", side_effect=lambda x, y: (x, y)):
                        _, encoded = module.transform(image, consensus)
                    torch.testing.assert_close(encoded[1], torch.full_like(encoded[1], probability))
                    torch.testing.assert_close(encoded.sum(0), torch.ones_like(encoded[0]))

    def test_train_step_samples_consensus_once_before_discrete_diffusion(self):
        for stage in (1, 2):
            with self.subTest(stage=stage):
                diffusion = DiffusionModel("cosine", 250, 2)
                model = DenoisingModel(diffusion, TinyUNet(), "datasets.lidc")
                trainer = Trainer(
                    PolyakAverager(model, copy.deepcopy(model)),
                    torch.optim.Adam(model.parameters(), lr=1e-4), None,
                    torch.ones(2), None, None,
                    {"stage": stage, "feature_cond_encoder": {"train": False}},
                )
                foreground = torch.tensor([0.25, 0.75] if stage == 1 else [0., 1.])[:, None, None].expand(2, 64, 64)
                target = torch.stack((1 - foreground, foreground), dim=1)
                batch = (torch.zeros(2, 1, 64, 64), target)
                if stage == 2:
                    batch = (batch[0], torch.tensor([0, 1]), target)
                with patch("ddpm.trainer.idist.device", return_value=torch.device("cpu")), patch("ddpm.trainer.np.save"), patch("ddpm.trainer.torch.randint", return_value=torch.tensor([1, 250])), patch.object(diffusion, "q_xt_given_x0", wraps=diffusion.q_xt_given_x0) as forward, patch.object(diffusion, "theta_post", wraps=diffusion.theta_post) as posterior:
                    result = trainer.train_step(None, batch)
                sampled = forward.call_args_list[0].args[0]
                self.assertTrue(((sampled == 0) | (sampled == 1)).all().item())
                torch.testing.assert_close(sampled.sum(1), torch.ones_like(foreground))
                torch.testing.assert_close(sampled[:, 1].mean((1, 2)), foreground.mean((1, 2)), atol=0.025, rtol=0)
                torch.testing.assert_close(forward.call_args_list[1].args[0], sampled)
                torch.testing.assert_close(posterior.call_args.args[1], sampled)
                if stage == 2:
                    torch.testing.assert_close(sampled, target)
                self.assertTrue(np.isfinite(result["loss"]))
                self.assertTrue(all(torch.isfinite(p.grad).all().item() for p in model.parameters()))

    def test_cosine_marginal_matches_markov_transitions_and_posterior(self):
        diffusion = DiffusionModel("cosine", 250, 2)
        marginal = torch.eye(2, dtype=torch.float64)
        for t in range(1, 251):
            transition = diffusion.alphas[t - 1].double() * torch.eye(2, dtype=torch.float64) + diffusion.betas[t - 1].double() / 2
            previous = marginal
            marginal = marginal @ transition
            if t not in (1, 10, 100, 249, 250):
                continue
            for initial in (0, 1):
                x0 = torch.eye(2)[initial].reshape(1, 2, 1, 1)
                time = torch.tensor([t])
                expected = marginal[initial].float().reshape_as(x0)
                observed = diffusion.q_xt_given_x0(x0, time).prob_sample()
                torch.testing.assert_close(observed, expected, atol=1e-6, rtol=1e-5)
                for noisy in (0, 1):
                    xt = torch.eye(2)[noisy].reshape_as(x0)
                    posterior = previous[initial] * transition[:, noisy]
                    posterior = (posterior / posterior.sum()).float().reshape_as(x0)
                    # Float32 cumulative products amplify rounding for rare transitions.
                    torch.testing.assert_close(diffusion.theta_post(xt, x0, time), posterior, atol=1e-5, rtol=1e-4)
                    torch.testing.assert_close(diffusion.theta_post_prob(xt, x0, time), posterior, atol=1e-5, rtol=1e-4)
        self.assertLess(diffusion.cumalphas[-1].item(), 1e-6)

    def test_cosine_schedule_respects_offset_and_last_step_boundary(self):
        default = DiffusionModel("cosine", 250, 2)
        custom = DiffusionModel("cosine", 250, 2, {"s": 0.1})
        self.assertFalse(torch.equal(default.betas, custom.betas))
        xt = torch.tensor([0., 1.]).reshape(1, 2, 1, 1)
        prediction = torch.tensor([0.3, 0.7]).reshape_as(xt)
        torch.testing.assert_close(default.theta_post_prob(xt, prediction, torch.tensor([1])), prediction)

    def test_lidc_train_eval_use_identical_unit_range(self):
        labels = np.zeros((128, 128), dtype=np.float32)
        raw = np.arange(128 * 128, dtype=np.uint8).reshape(1, 128, 128)
        with patch("datasets.lidc.torch.rand", return_value=torch.ones(1)), patch("datasets.lidc.np.random.randint", return_value=0):
            train, _ = lidc.transform(raw, labels)
        evaluation, _ = lidc.batch_transform(raw, {str(i): labels.copy() for i in range(4)})
        torch.testing.assert_close(train, torch.from_numpy(raw).float() / 255)
        torch.testing.assert_close(train, evaluation)

    def test_npc_train_eval_normalize_each_modality_and_constant_slice(self):
        base = np.linspace(0, 1, 32 * 40, dtype=np.float32).reshape(32, 40)
        raw = np.stack((base * 3 - 2, base * 100 + 15, np.full_like(base, -5)))
        labels = np.zeros((32, 40), dtype=np.float32)
        with patch("datasets.npc_170.random.random", return_value=0):
            train, _ = npc_170.transform(raw, labels)
        evaluation, _ = npc_170.batch_transform(raw, {str(i): labels.copy() for i in range(4)})
        torch.testing.assert_close(train, evaluation)
        torch.testing.assert_close(train[0], train[1])
        torch.testing.assert_close(train[2], torch.zeros_like(train[2]))
        self.assertEqual(train.min().item(), 0)
        self.assertEqual(train.max().item(), 1)
        self.assertTrue(torch.isfinite(train).all().item())
        with patch("datasets.npc_170.random.random", side_effect=[0, 0, 1]):
            augmented, _ = npc_170.transform(raw, labels)
        self.assertGreaterEqual(augmented.min().item(), 0)
        self.assertLessEqual(augmented.max().item(), 1)

    def test_train_step_samples_full_time_range_and_keeps_debug_sampling(self):
        model = DenoisingModel(DiffusionModel("cosine", 250, 2), TinyUNet(), "datasets.lidc")
        polyak = PolyakAverager(model, copy.deepcopy(model))
        trainer = Trainer(
            polyak, torch.optim.Adam(model.parameters(), lr=1e-4), None,
            torch.ones(2), None, None,
            {"stage": 1, "feature_cond_encoder": {"train": False}},
        )
        target = torch.nn.functional.one_hot(torch.randint(2, (250, 4, 4)), 2)
        batch = (torch.zeros(250, 1, 4, 4), target.permute(0, 3, 1, 2).float())
        with patch("ddpm.trainer.idist.device", return_value=torch.device("cpu")), patch("ddpm.trainer.np.save") as save, patch("ddpm.trainer.torch.randint", wraps=torch.randint) as randint:
            trainer.train_step(None, batch)
            trainer.train_step(None, batch)
        self.assertEqual(randint.call_count, 2)
        for call in randint.call_args_list:
            self.assertEqual(call.args, (1, 251))
            self.assertEqual(call.kwargs["size"], (250,))
        self.assertTrue(all(1 <= t <= 250 for t in model.unet.timesteps))
        self.assertLess(min(model.unet.timesteps), 10)
        self.assertGreater(max(model.unet.timesteps), 240)
        self.assertEqual(save.call_count, 4)


if __name__ == "__main__":
    unittest.main()
