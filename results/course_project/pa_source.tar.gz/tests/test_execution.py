import copy
import random
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import h5py
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, RandomSampler, SubsetRandomSampler

from datasets import npc_170
from ddpm.polyak import PolyakAverager
from ddpm.trainer import Trainer
from reproduction.execution import ExecutionTrainer, StatefulSampler, cache_npc_raw
from reproduction.performance import ForeachEMA


class RandomData(Dataset):
    def __len__(self):
        return 31

    def __getitem__(self, index):
        return index, torch.rand(2), random.random(), np.random.random()


def seed():
    torch.manual_seed(71)
    random.seed(71)
    np.random.seed(71)


class ExecutionTests(unittest.TestCase):
    def test_sampler_matches_source_and_resumes_without_changing_batches(self):
        for kind in ("subset", "random"):
            for cut in (3, 8):
                with self.subTest(kind=kind, cut=cut):
                    data = RandomData()
                    make_sampler = lambda: (SubsetRandomSampler(list(range(31))[::-1])
                                            if kind == "subset" else RandomSampler(data))
                    seed()
                    original = DataLoader(data, batch_size=4, sampler=make_sampler())
                    expected = [batch for _ in range(2) for batch in original]
                    expected_rng = torch.get_rng_state()
                    seed()
                    sampler = StatefulSampler(make_sampler())
                    loader = DataLoader(data, batch_size=4, sampler=sampler)
                    iterator = iter(loader)
                    actual = [next(iterator) for _ in range(cut)]
                    sampler_state = sampler.state_dict()
                    saved_rng = torch.get_rng_state()
                    restored = StatefulSampler(make_sampler())
                    restored.load_state_dict(sampler_state)
                    loader = DataLoader(data, batch_size=4, sampler=restored)
                    iterator = iter(loader)
                    # A replacement iterator must not consume another base seed.
                    torch.set_rng_state(saved_rng)
                    actual.extend(iterator)
                    actual.extend(loader)
                    for before, after in zip(expected, actual):
                        for x, y in zip(before, after):
                            self.assertTrue(torch.equal(x, y))
                    self.assertEqual(len(actual), len(expected))
                    self.assertTrue(torch.equal(expected_rng, torch.get_rng_state()))

    def test_cache_preserves_augmented_samples_and_avoids_hdf5_reads(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary) / "training_2d"
            directory.mkdir()
            with h5py.File(directory / "case.h5", "w") as stream:
                for i, name in enumerate(("t1", "t1c", "t2")):
                    stream[name] = np.arange(128 * 128, dtype=np.float32).reshape(128, 128) / (i + 1)
                for i in range(4):
                    stream[f"label_a{i + 1}"] = np.eye(128, dtype=np.uint8)
            for stage in (1, 2):
                train = npc_170.NPC_170(stage, temporary, transform=npc_170.transform)
                seed()
                expected = [train[0] for _ in range(12)]
                expected_rng = (torch.get_rng_state(), np.random.get_state(), random.getstate())
                seed()
                cache_npc_raw(train)
                with patch("datasets.npc_170.h5py.File", side_effect=AssertionError("cache missed")):
                    actual = [train[0] for _ in range(12)]
                for before, after in zip(expected, actual):
                    for x, y in zip(before, after):
                        self.assertTrue(torch.equal(x, y) if torch.is_tensor(x) else x == y)
                self.assertTrue(torch.equal(expected_rng[0], torch.get_rng_state()))
                np.testing.assert_array_equal(expected_rng[1][1], np.random.get_state()[1])
                self.assertEqual(expected_rng[1][2:], np.random.get_state()[2:])
                self.assertEqual(expected_rng[2], random.getstate())

    def test_foreach_ema_is_bitwise_equal_including_integer_buffers(self):
        model = torch.nn.BatchNorm1d(3)
        reference = PolyakAverager(model, copy.deepcopy(model), 0.9999)
        optimized = ForeachEMA(model, copy.deepcopy(model), 0.9999)
        for i in range(10):
            with torch.no_grad():
                model.weight.copy_(torch.randn_like(model.weight))
                model.running_mean.copy_(torch.randn_like(model.running_mean))
                model.num_batches_tracked.fill_(i * 19)
            reference.update()
            optimized.update()
        for name, value in reference.average_model.state_dict().items():
            self.assertTrue(torch.equal(value, optimized.average_model.state_dict()[name]))

    def test_combined_check_keeps_original_failure_path(self):
        trainer = object.__new__(ExecutionTrainer)
        with patch.object(Trainer, "_check_loss") as original:
            trainer._check_loss(torch.ones(2, 2, 3, 3), {})
            original.assert_not_called()
            for value in (float("nan"), float("inf"), -0.01):
                loss = torch.full((2, 2, 3, 3), value)
                context = {}
                trainer._check_loss(loss, context)
                self.assertIs(original.call_args.args[0], loss)
                self.assertIs(original.call_args.args[1], context)
            self.assertEqual(original.call_count, 3)


if __name__ == "__main__":
    unittest.main()
