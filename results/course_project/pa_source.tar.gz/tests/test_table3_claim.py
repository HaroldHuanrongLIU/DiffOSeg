import random
import unittest
from unittest.mock import patch

import numpy as np
import torch
from torch.utils.data import DataLoader, SubsetRandomSampler

from datasets.lidc import LIDC_IDRI, transform
from reproduction.table3_claim import AverageLIDC, worker_parameters, claim_transform
from reproduction.table3_analysis import paired_bootstrap, classify


class Table3Tests(unittest.TestCase):
    def dataset(self, cls):
        data = object.__new__(cls)
        data.stage, data.num_experts, data.transform = 1, 4, claim_transform
        data.images = [np.arange(64, dtype=np.uint8).reshape(8, 8)] * 5
        masks = [np.pad(np.ones((i + 1, i + 1), dtype=np.uint8),
                        ((0, 7 - i), (0, 7 - i))) for i in range(4)]
        data.mask_labels, data.series_uid = [masks] * 5, list(range(5))
        return data

    def test_average_uses_all_labels_and_preserves_pair_rng(self):
        p, a = self.dataset(LIDC_IDRI), self.dataset(AverageLIDC)
        outputs = []
        for data in (p, a):
            random.seed(71)
            np.random.seed(71)
            torch.manual_seed(71)
            sampler = SubsetRandomSampler(range(5))
            batches = list(DataLoader(data, batch_size=2, sampler=sampler))
            outputs.append((batches, random.getstate(), np.random.get_state(),
                            torch.get_rng_state(), torch.rand(9)))
        self.assertEqual(outputs[0][1], outputs[1][1])
        np.testing.assert_array_equal(outputs[0][2][1], outputs[1][2][1])
        self.assertTrue(torch.equal(outputs[0][3], outputs[1][3]))
        self.assertTrue(torch.equal(outputs[0][4], outputs[1][4]))
        for left, right in zip(outputs[0][0], outputs[1][0]):
            self.assertTrue(torch.equal(left[0], right[0]))
        with patch("datasets.lidc.random.randint", return_value=1), \
             patch("datasets.lidc.random.sample", return_value=[0]):
            np.testing.assert_array_equal(p._generate_probabilistic_weights(), [1, 0, 0, 0])
            np.testing.assert_array_equal(a._generate_probabilistic_weights(), [1, 1, 1, 1])
        actual = a._compute_consensus_label(a.mask_labels[0], np.ones(4))
        np.testing.assert_array_equal(actual, np.mean(a.mask_labels[0], axis=0))
        self.assertTrue(np.any((actual > 0) & (actual < 1)))

    def test_intensity_scaling_is_shared_and_preserves_labels(self):
        image = np.full((1, 8, 8), 255, dtype=np.uint8)
        label = np.full((8, 8), 0.5, dtype=np.float32)
        with patch("reproduction.table3_claim.np.random.uniform", return_value=0.9):
            result, target = claim_transform(image, label)
        torch.testing.assert_close(result, torch.full_like(result, 0.9))
        torch.testing.assert_close(target, torch.full_like(target, 0.5))
        with patch("reproduction.table3_claim.np.random.uniform", return_value=1.1):
            result, _ = claim_transform(image, label)
        self.assertEqual(float(result.max()), 1.0)

    def test_primary_bootstrap_includes_training_seed_variation(self):
        a = np.zeros((3, 4, 2))
        p = np.zeros_like(a)
        p[0, :, :] = [-0.1, 0.1]
        p[2, :, :] = [0.1, -0.1]
        primary = paired_bootstrap(p, a, ["x", "x", "y", "y"], nboot=1000)
        conditional = paired_bootstrap(p, a, ["x", "x", "y", "y"], nboot=1000, sample_seeds=False)
        self.assertLess(primary["difference_ci95"][0][0], 0)
        self.assertGreater(primary["difference_ci95"][0][1], 0)
        np.testing.assert_allclose(conditional["difference_ci95"], 0, atol=1e-15)

    def test_worker_parameters_separate_split_train_evaluation_seeds(self):
        base = {"datasets": {}, "seed": 1337}
        left = worker_parameters(base, "P", 20261, False)
        right = worker_parameters(base, "A", 20261, False)
        self.assertEqual(left["seed"], 1337)
        self.assertEqual(left["training_seed"], 20261)
        self.assertEqual(left["run_seed"], right["run_seed"])
        self.assertEqual(left["steps"], 120000)
        self.assertEqual(left["consensus_samples"], [30])
        self.assertEqual(left["sampling_batch_size"], 30)
        self.assertEqual({k: v for k, v in left.items() if k != "condition"},
                         {k: v for k, v in right.items() if k != "condition"})
        self.assertNotEqual(left["training_seed"],
                            worker_parameters(base, "P", 20262, False)["training_seed"])

    def test_paired_bootstrap_preserves_constant_improvement(self):
        a = np.ones((3, 6, 2)) * 0.4
        p = a + np.array([-0.02, 0.03])
        result = paired_bootstrap(p, a, ["x", "x", "x", "y", "z", "z"], nboot=100)
        np.testing.assert_allclose(result["difference_ci95"], [[-0.02, -0.02], [0.03, 0.03]])
        self.assertEqual(result["decision"], "supported")
        reverse = paired_bootstrap(a, p, ["x", "x", "x", "y", "z", "z"], nboot=100)
        self.assertEqual(reverse["decision"], "not_supported")

    def test_identical_conditions_are_inconclusive(self):
        values = np.random.default_rng(4).random((3, 8, 2))
        result = paired_bootstrap(values, values, [0, 0, 1, 1, 2, 2, 3, 3], nboot=100)
        self.assertEqual(result["difference_ci95"], [[0.0, 0.0], [0.0, 0.0]])
        self.assertEqual(result["decision"], "inconclusive")
        self.assertEqual(classify([[-0.02, 0.01], [0.01, 0.02]]), "inconclusive")
        self.assertEqual(classify([[-0.02, -0.01], [-0.02, -0.01]]), "not_supported")

    def test_cluster_bootstrap_keeps_siblings_together(self):
        # One patient has four identical slices; another has one. This must use
        # the slice-weighted estimator with whole-patient resampling.
        a = np.zeros((3, 5, 2))
        p = a.copy()
        p[:, :4] = [-0.01, 0.02]
        p[:, 4:] = [-0.11, 0.12]
        result = paired_bootstrap(p, a, ["x"] * 4 + ["y"], nboot=1000)
        np.testing.assert_allclose(result["difference"], [-0.03, 0.04])
        np.testing.assert_allclose(result["difference_ci95"], [[-0.11, -0.01], [0.02, 0.12]])


if __name__ == "__main__":
    unittest.main()
