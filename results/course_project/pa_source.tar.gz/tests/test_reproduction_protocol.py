import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from reproduction.data import patient_folds, source_folds, datasets_for_run
from reproduction.metrics import consensus_scores, pairwise_scores, preference_scores
from reproduction.run import paper_comparison, save_masks, load_masks
from metrics_set import generalized_energy_distance


class ReproductionProtocolTests(unittest.TestCase):
    def test_patient_split_can_use_released_loader_without_patient_leakage(self):
        uids = [f"{patient}_slice{image}" for patient in range(20) for image in range(4)]
        with patch("reproduction.data.lidc.LIDC_IDRI") as train_class, patch("reproduction.data.lidc.Test_LIDC"):
            train_class.return_value.series_uid = uids
            for fold, expected in enumerate(patient_folds(uids)):
                train, test, metadata = datasets_for_run(
                    "/unused", "lidc", 1, fold, 1337,
                    released_source=True, lidc_split="patient",
                )
                self.assertEqual(train.indices, expected["train_indices"])
                self.assertEqual(test.indices, expected["test_indices"])
                self.assertFalse(set(metadata["train_patients"]) & set(metadata["test_patients"]))
                self.assertEqual(metadata["evaluation_split"], "held_out_patients")

    def test_source_folds_match_released_slice_split(self):
        from sklearn.model_selection import KFold
        uids = [f"{patient}_slice{image}" for patient in range(20) for image in range(4)]
        indices = list(range(len(uids)))
        np.random.RandomState(1337).shuffle(indices)
        folds = source_folds(uids)
        for actual, (train, test) in zip(folds, KFold(4, shuffle=False).split(indices)):
            self.assertEqual(actual["train_indices"], [indices[i] for i in train])
            self.assertEqual(actual["test_indices"], [indices[i] for i in test])
            self.assertFalse(set(actual["train_indices"]) & set(actual["test_indices"]))
            self.assertTrue(actual["overlapping_patients"])

    def test_patient_folds_never_share_a_patient(self):
        uids = [f"{patient}_slice{image}" for patient in range(214) for image in range(2)]
        folds = patient_folds(uids)
        self.assertEqual([len(f["test_patients"]) for f in folds], [54, 54, 53, 53])
        seen = []
        for fold in folds:
            self.assertFalse(set(fold["train_patients"]) & set(fold["test_patients"]))
            self.assertFalse(set(fold["train_indices"]) & set(fold["test_indices"]))
            self.assertEqual(len(fold["train_indices"]) + len(fold["test_indices"]), len(uids))
            seen.extend(fold["test_indices"])
        self.assertEqual(sorted(seen), list(range(len(uids))))
        self.assertEqual(folds, patient_folds(uids))

    def test_empty_masks_match(self):
        empty = np.zeros((4, 8, 8), dtype=bool)
        dice, iou = pairwise_scores(empty, empty)
        np.testing.assert_array_equal(dice, 1)
        np.testing.assert_array_equal(iou, 1)
        score = consensus_scores(empty, empty)
        self.assertEqual(score["GED"], 0)
        self.assertEqual(score["Dice_soft"], 1)

    def test_reported_ged_matches_released_reference_with_empty_masks(self):
        labels = np.zeros((4, 8, 8), dtype=bool)
        labels[2:] = True
        predictions = np.zeros((4, 8, 8), dtype=bool)
        reference = generalized_energy_distance(
            torch.from_numpy(labels[None]), torch.from_numpy(predictions[None])
        )
        self.assertAlmostEqual(consensus_scores(labels, predictions)["GED"], reference, places=6)
        self.assertEqual(consensus_scores(labels, predictions)["GED_empty_match"], 0.5)

    def test_saved_masks_round_trip_with_padding_bits(self):
        generator = np.random.default_rng(7)
        truth = generator.integers(0, 2, (4, 2, 3, 3)).astype(bool)
        predictions = generator.integers(0, 2, (5, 2, 3, 3)).astype(bool)
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "masks.npz"
            save_masks(path, truth, predictions)
            restored_truth, restored_predictions = load_masks(path)
        np.testing.assert_array_equal(restored_truth, truth)
        np.testing.assert_array_equal(restored_predictions, predictions)

    def test_consensus_matching_must_not_replace_expert_identity(self):
        labels = np.eye(4, dtype=bool).reshape(4, 2, 2)
        shuffled = np.roll(labels, 1, axis=0)
        self.assertEqual(consensus_scores(labels, shuffled)["Dice_match"], 1)
        self.assertEqual(preference_scores(labels, shuffled)["Dice_mean"], 0)
        self.assertEqual(preference_scores(labels, labels)["Dice_each"], [1, 1, 1, 1])
        with self.assertRaises(ValueError):
            preference_scores(labels, labels[:3])

    def test_partial_folds_and_smoke_do_not_become_paper_comparisons(self):
        rows = []
        for fold in range(4):
            rows.append({"results": {
                "dataset": "lidc", "stage": 2, "fold": fold,
                "classification": "paper_budget_with_documented_assumptions",
                "metrics": {"Dice_each": [0.5] * 4},
            }})
        self.assertEqual(paper_comparison(rows[:3])["lidc_stage_2"]["state"], "incomplete")
        self.assertEqual(paper_comparison(rows)["lidc_stage_2"]["metrics"][-1]["observed"], 0.5)
        for row in rows:
            row["results"]["classification"] = "engineering_smoke"
        self.assertEqual(paper_comparison(rows)["lidc_stage_2"]["completed_folds"], 0)
        for row in rows:
            row["results"]["classification"] = "released_source_slice_folds"
        comparison = paper_comparison(rows)
        self.assertEqual(comparison["lidc_stage_2"]["completed_folds"], 0)
        self.assertEqual(comparison["source_run"]["state"], "not_a_patient_disjoint_paper_comparison")
        for row in rows:
            row["results"]["classification"] = "corrected_diffusion_slice_folds"
        self.assertEqual(paper_comparison(rows)["lidc_stage_2"]["completed_folds"], 0)


if __name__ == "__main__":
    unittest.main()
