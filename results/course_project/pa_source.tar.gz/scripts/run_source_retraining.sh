#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd -- "$project_dir"
run_output="${1:?Usage: bash scripts/run_source_retraining.sh OUTPUT_DIR [--smoke]}"
shift

# Finish all training before evaluation so evaluation reseeding cannot affect training.
for phase in train evaluate; do
    bash scripts/run_reproduction.sh "$run_output" \
        --config "$project_dir/configs/reproduction_source.yml" --phase "$phase" "$@"
done
