#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd -- "$project_dir"
run_output="${1:?Usage: bash scripts/run_reproduction.sh OUTPUT_DIR [--smoke]}"
shift
mkdir -p -- "$run_output"

export PYTHONDONTWRITEBYTECODE=1
export CUDA_VISIBLE_DEVICES=0
export OMP_NUM_THREADS=4
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=4

uv lock --check --offline
.venv/bin/python -u -B -m reproduction.run --output "$run_output" "$@" 2>&1 | tee -a "$run_output/tmux.log"
