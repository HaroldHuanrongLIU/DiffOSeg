"""Run fixed-budget experiments using the repository's datasets, UNet and Trainer."""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import random
import shutil
import subprocess
import tarfile
import time
import traceback
from importlib.metadata import distributions

import numpy as np
import torch
from torch.utils.data import DataLoader, RandomSampler, SubsetRandomSampler
import yaml

from ddpm.models.one_hot_categorical import OneHotCategoricalBCHW
from ddpm.polyak import PolyakAverager
from ddpm.optimizer import build_optimizer
from ddpm.trainer import Trainer, _build_model
from ddpm.utils import worker_init_fn
from reproduction.data import datasets_for_run, training_sizes
from reproduction.metrics import consensus_scores, preference_scores
from reproduction.performance import ForeachEMA, ContinuousBatchSampler, reference_sample_budget
from reproduction.execution import ExecutionTrainer, StatefulSampler, cache_npc_raw, prepare_debug_directory


ROOT = Path(__file__).resolve().parents[1]
TRAINING_PROTOCOL = "categorical_full_t_consensus_sample_unit_range_v1"


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_checkpoint(path, source_id, config_id=None):
    state = torch.load(path, map_location="cpu", weights_only=False)
    if state.get("training_protocol") != TRAINING_PROTOCOL:
        raise ValueError(f"Checkpoint training protocol differs; use its archived source for historical evaluation: {path}")
    if config_id is not None and state["config_id"] != config_id:
        raise ValueError(f"Checkpoint config differs: {path}")
    if state["source_id"] != source_id:
        origin_path = path.parent / "checkpoint_origin.json"
        if not origin_path.exists():
            raise ValueError(f"Checkpoint source differs: {path}")
        origin = json.loads(origin_path.read_text())
        if (origin["source_id"] != state["source_id"] or origin["config_id"] != state["config_id"]
                or origin["sha256"] != sha256(path)):
            raise ValueError(f"Inherited checkpoint provenance differs: {path}")
    return state


def validate_run_protocol(output):
    environment = Path(output) / "environment.json"
    if environment.exists():
        recorded = json.loads(environment.read_text()).get("training_protocol")
        if recorded != TRAINING_PROTOCOL:
            raise ValueError(f"Run training protocol differs; choose a new output directory: {output}")


def inherit_completed_runs(previous, output, input_hashes):
    previous = Path(previous).resolve()
    if previous == output:
        raise ValueError("Inherited runs require a separate output directory")
    validate_run_protocol(previous)
    if json.loads((previous / "input_hashes.json").read_text()) != input_hashes:
        raise ValueError("Inherited run uses different dataset bytes")
    source = json.loads((previous / "environment.json").read_text())["source_id"]
    for checkpoint in sorted(previous.glob("*/fold_*/stage_*/final.pt")):
        original = checkpoint.parent
        params = json.loads((original / "config.json").read_text())
        config_id = hashlib.sha256(json.dumps(params, sort_keys=True).encode()).hexdigest()
        state = read_checkpoint(checkpoint, source, config_id)
        if state["step"] != params["steps"]:
            raise ValueError(f"Incomplete checkpoint cannot be inherited: {checkpoint}")
        destination = output / original.relative_to(previous)
        destination.mkdir(parents=True, exist_ok=True)
        checksum = sha256(checkpoint)
        for name in ("config.json", "split.json", "training.jsonl", "initialization.json"):
            if (original / name).exists() and not (destination / name).exists():
                shutil.copyfile(original / name, destination / name)
        for name in ("final.pt", "last.pt"):
            target = destination / name
            if target.exists():
                if sha256(target) != checksum:
                    raise ValueError(f"Refusing to replace checkpoint: {target}")
            else:
                os.link(checkpoint, target)
        atomic_json(destination / "checkpoint_origin.json", {
            "path": str(checkpoint), "sha256": checksum, "source_id": state["source_id"],
            "config_id": config_id, "step": state["step"], "batch_size": params["batch_size"],
            "note": "Completed training preserved; evaluation will use the new execution settings.",
        })
        if not (destination / "results.json").exists():
            atomic_json(destination / "status.json", {"state": "trained", "step": state["step"],
                        "target_steps": params["steps"], "classification": params["classification"], "inherited": True})
        print(f"INHERITED {checkpoint}: step={state['step']}, batch={params['batch_size']}", flush=True)
        del state


def save_masks(path, truth, predictions):
    temporary = path.with_suffix(".tmp")
    with temporary.open("wb") as stream:
        np.savez_compressed(stream, truth=np.packbits(truth), predictions=np.packbits(predictions),
                            truth_shape=np.array(truth.shape), prediction_shape=np.array(predictions.shape))
    temporary.replace(path)


def load_masks(path):
    with np.load(path, allow_pickle=False) as data:
        truth_shape = tuple(data["truth_shape"])
        prediction_shape = tuple(data["prediction_shape"])
        truth = np.unpackbits(data["truth"])[:np.prod(truth_shape)].reshape(truth_shape).astype(bool)
        predictions = np.unpackbits(data["predictions"])[:np.prod(prediction_shape)].reshape(prediction_shape).astype(bool)
    return truth, predictions


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def snapshot(output):
    paths = []
    for directory in ("ddpm", "datasets", "reproduction", "configs", "tests", "scripts"):
        paths.extend(p for p in (ROOT / directory).rglob("*") if p.suffix in (".py", ".yml", ".yaml", ".sh"))
    paths.extend(ROOT / name for name in ("uv.lock", "pyproject.toml", "INSTALL.md", "params.yml"))
    digest = hashlib.sha256()
    for path in sorted(paths):
        digest.update(str(path.relative_to(ROOT)).encode())
        digest.update(path.read_bytes())
    source_id = digest.hexdigest()
    archive = output / f"source-{source_id[:12]}.tar.gz"
    if not archive.exists():
        with tarfile.open(archive, "w:gz") as tar:
            for path in sorted(paths):
                tar.add(path, arcname=str(path.relative_to(ROOT)))
    return source_id


def model_for(params, train):
    sample = train[0]
    shapes = [sample[0].shape, sample[-1].shape]
    return _build_model(params, shapes, shapes[0])


def save_checkpoint(path, model, average, optimizer, scheduler, step, config_id, source_id, samples_seen=None,
                    sampler=None):
    state = {
        "model": model.unet.state_dict(), "average_model": average.unet.state_dict(),
        "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(),
        "step": step, "config_id": config_id, "source_id": source_id,
        "training_protocol": TRAINING_PROTOCOL,
        "samples_seen": samples_seen,
        "rng_python": random.getstate(), "rng_numpy": np.random.get_state(),
        "rng_torch": torch.get_rng_state(), "rng_cuda": torch.cuda.get_rng_state_all(),
    }
    if sampler is not None:
        state["sampler"] = sampler.state_dict()
    temporary = path.with_suffix(".tmp")
    torch.save(state, temporary)
    temporary.replace(path)


def train_experiment(params, train, directory, source_id, stage1_path, execution_profile="original"):
    config_id = hashlib.sha256(json.dumps(params, sort_keys=True).encode()).hexdigest()
    final_path = directory / "final.pt"
    last_path = directory / "last.pt"
    if final_path.exists():
        state = read_checkpoint(final_path, source_id, config_id)
        if state["step"] != params["steps"]:
            raise ValueError(f"Completed checkpoint step differs: {final_path}")
        return
    released_source = params.get("released_source", False)
    optimized = execution_profile == "optimized"
    sampler = None
    if released_source:
        if not last_path.exists():
            torch.save({
                "python": random.getstate(), "numpy": np.random.get_state(),
                "torch": torch.get_rng_state(), "cuda": torch.cuda.get_rng_state_all(),
            }, directory / "initial_rng.pt")
        # Preserve the released loader defaults and model-initialization RNG use.
        if optimized:
            if params["dataset"] == "npc":
                cached_bytes = cache_npc_raw(train)
                print(f"RAW CACHE {cached_bytes / 2**30:.3f} GiB; stochastic transforms unchanged", flush=True)
            data = train.dataset if params["dataset"] == "lidc" else train
            source_sampler = (SubsetRandomSampler(train.indices) if params["dataset"] == "lidc"
                              else RandomSampler(train))
            sampler = StatefulSampler(source_sampler)
            loader = DataLoader(data, batch_size=params["batch_size"], sampler=sampler)
            sample = data[0]
        elif params["dataset"] == "lidc":
            loader = DataLoader(train.dataset, batch_size=params["batch_size"],
                                sampler=SubsetRandomSampler(train.indices))
            sample = train.dataset[0]
        else:
            loader = DataLoader(train, batch_size=params["batch_size"], shuffle=True)
            sample = train[0]
        shapes = [item.shape for item in sample if hasattr(item, "shape")]
        model, average = [_build_model(params, shapes, shapes[0]) for _ in range(2)]
    else:
        seed_all(params["run_seed"])
        model = model_for(params, train)
    if params["stage"] == 2 and not last_path.exists():
        state = read_checkpoint(stage1_path, source_id)
        current = model.unet.state_dict()
        loaded = {key: value for key, value in state["model"].items()
                  if key in current and value.shape == current[key].shape}
        missing, unexpected = model.unet.load_state_dict(loaded, strict=False)
        allowed_missing = lambda key: key.startswith("prompt_block.") or key == "input_blocks.0.0.weight"
        if not loaded or unexpected or any(not allowed_missing(key) for key in missing):
            raise ValueError(f"Unexpected stage transfer mismatch: {missing}, {unexpected}")
        atomic_json(directory / "initialization.json", {
            "stage1_checkpoint": str(stage1_path), "stage1_sha256": sha256(stage1_path),
            "loaded_tensors": len(loaded), "new_or_resized_tensors": missing,
            "all_parameters_trainable": all(p.requires_grad for p in model.parameters()),
        })
        del state, current, loaded
    if not released_source:
        average = copy.deepcopy(model)
    averager = ForeachEMA if optimized or params.get("foreach_ema", False) else PolyakAverager
    polyak = averager(model, average, alpha=params["polyak_alpha"])
    steps = params["steps"]
    budget = params.get("sample_budget")
    if released_source:
        staff = build_optimizer(params, model, None, loader)
        optimizer, scheduler = staff["optimizer"], staff["lr_scheduler"]
    else:
        optimizer = torch.optim.Adam(model.parameters(), lr=params["learning_rate"],
                                     **({"fused": True} if params.get("fused_adam", False) else {}))
        minimum = params["minimum_learning_rate"] / params["learning_rate"]
        final_batch = (budget - (steps - 1) * params["batch_size"]) if budget is not None else None
        scheduler = torch.optim.lr_scheduler.LambdaLR(
            optimizer, lambda step: minimum + (1 - minimum) * max(0, 1 - (
                step * params["batch_size"] / max(budget - final_batch, 1) if budget is not None
                else step / max(steps - 1, 1)))
        )
    trainer_class = ExecutionTrainer if optimized else Trainer
    trainer = trainer_class(polyak, optimizer, scheduler, torch.ones(2, device="cuda"),
                            None, None, params)
    start = 0
    samples_seen = 0
    if last_path.exists():
        state = read_checkpoint(last_path, source_id, config_id)
        model.unet.load_state_dict(state["model"])
        average.unet.load_state_dict(state["average_model"])
        optimizer.load_state_dict(state["optimizer"])
        scheduler.load_state_dict(state["scheduler"])
        start = state["step"]
        samples_seen = state.get("samples_seen") or reference_sample_budget(len(train), params["batch_size"], start)
        random.setstate(state["rng_python"])
        np.random.set_state(state["rng_numpy"])
        torch.set_rng_state(state["rng_torch"])
        torch.cuda.set_rng_state_all(state["rng_cuda"])
        if sampler is not None:
            if "sampler" not in state:
                raise ValueError("Exact resume requires a verified sampler state")
            sampler.load_state_dict(state["sampler"])
        del state
    batching = ({"batch_sampler": ContinuousBatchSampler(len(train), params["batch_size"], budget,
                  params["run_seed"], samples_seen)} if budget is not None
                else {"batch_size": params["batch_size"], "shuffle": True})
    if not released_source:
        loader = DataLoader(train, **batching,
                            num_workers=params["num_workers"], pin_memory=True,
                            persistent_workers=params["num_workers"] > 0,
                            worker_init_fn=worker_init_fn,
                            generator=torch.Generator().manual_seed(params["run_seed"] + start))
    resume_rng = torch.get_rng_state() if start and sampler is not None else None
    iterator = iter(loader)
    if resume_rng is not None:
        # Replacement iterator initialization must not draw a second base seed.
        torch.set_rng_state(resume_rng)
    started = time.monotonic()
    initial_samples = samples_seen
    print(f"TRAIN {directory} from {start} to {steps}; samples={len(train)}; "
          f"parameters={sum(p.numel() for p in model.parameters()):,}", flush=True)
    with (directory / "training.jsonl").open("a", buffering=1) as log:
        for step in range(start + 1, steps + 1):
            try:
                batch = next(iterator)
            except StopIteration:
                iterator = iter(loader)
                batch = next(iterator)
            if params.get("ema_per_sample", False):
                polyak.alpha = params["polyak_alpha"] ** (len(batch[0]) / params["reference_batch_size"])
            result = trainer.train_step(None, batch)
            samples_seen += len(batch[0])
            if not math.isfinite(result["loss"]):
                raise FloatingPointError(f"Nonfinite loss at step {step}")
            if step == start + 1 or step % params["log_every"] == 0 or step == steps:
                elapsed = time.monotonic() - started
                rate = (step - start) / elapsed
                record = {
                    "state": "training", "step": step, "target_steps": steps,
                    "loss": result["loss"], "lr": result["lr"], "steps_per_second": rate,
                    "eta_hours": (steps - step) / rate / 3600,
                    "cuda_peak_gib": torch.cuda.max_memory_allocated() / 2**30,
                    "classification": params["classification"], "time": time.time(),
                    "batch_size": params["batch_size"], "samples_seen": samples_seen,
                    "sample_budget": budget, "images_per_second": (samples_seen - initial_samples) / elapsed,
                    "cuda_allocated_gib": torch.cuda.memory_allocated() / 2**30,
                    "cuda_reserved_gib": torch.cuda.memory_reserved() / 2**30,
                    "gpu_util_percent": torch.cuda.utilization(),
                }
                log.write(json.dumps(record) + "\n")
                atomic_json(directory / "status.json", record)
                report(directory.parents[2])
                print(json.dumps(record), flush=True)
            if step % params["checkpoint_every"] == 0 or step == steps:
                save_checkpoint(last_path, model, average, optimizer, scheduler,
                                step, config_id, source_id, samples_seen, sampler=sampler)
    if budget is not None and samples_seen != budget:
        raise ValueError(f"Sample budget mismatch: {samples_seen} != {budget}")
    # Last and final are the same completed fixed-budget checkpoint, without duplicating GBs.
    os.link(last_path, final_path)
    atomic_json(directory / "status.json", {
        "state": "trained", "step": steps, "target_steps": steps,
        "classification": params["classification"], "time": time.time(),
        "samples_seen": samples_seen, "sample_budget": budget,
    })
    del iterator, loader, trainer, optimizer, scheduler, polyak, average, model
    torch.cuda.empty_cache()


@torch.inference_mode()
def sample_foreground(model, image, count, batch_size, expert=None):
    parts = []
    device = next(model.parameters()).device
    for offset in range(0, count, batch_size):
        size = min(batch_size, count - offset)
        hint = image[None].to(device).expand(size, -1, -1, -1).contiguous()
        logits = torch.zeros(size, 2, *image.shape[-2:], device=device)
        noise = OneHotCategoricalBCHW(logits=logits).sample()
        condition = {"hint": hint}
        if expert is not None:
            condition["txt"] = (expert[offset:offset + size].to(device) if isinstance(expert, torch.Tensor)
                                else torch.full((size,), expert, device=device, dtype=torch.long))
        probability = model(noise, condition)["diffusion_out"]
        parts.append(probability[:, 1].cpu().numpy())
    return np.concatenate(parts)


def sample_experts(model, image, count, batch_size):
    experts = torch.arange(4).repeat_interleave(count)
    return sample_foreground(model, image, 4 * count, batch_size, experts).reshape(4, count, *image.shape[-2:])


def evaluate_experiment(params, train, dataset, directory, source_id, sampling_batch_size=None):
    if (directory / "results.json").exists():
        return
    model = model_for(params, train)
    state = read_checkpoint(directory / "final.pt", source_id)
    training_source_id = state["source_id"]
    model.unet.load_state_dict(state["average_model"])
    model.eval()
    del state
    counts = params["consensus_samples"]
    sampling_batch_size = sampling_batch_size or params["sampling_batch_size"]
    total = min(len(dataset), params.get("evaluation_cases", len(dataset)))
    case_directory = directory / "cases"
    case_directory.mkdir(exist_ok=True)
    records = []
    for index in range(total):
        result_path = case_directory / f"{index:05d}.json"
        if result_path.exists():
            records.append(json.loads(result_path.read_text()))
            continue
        seed_all(params["run_seed"] + index)
        image, labels = dataset[index]
        volume = image.ndim == 4
        images = image.permute(1, 0, 2, 3) if volume else image[None]
        truth = labels.argmax(2 if volume else 1).numpy().astype(bool)
        if "evaluation_slices" in params and volume:
            images = images[:params["evaluation_slices"]]
            truth = truth[:, :params["evaluation_slices"]]
        started = time.monotonic()
        if params["stage"] == 1:
            predictions = np.stack([
                sample_foreground(model, frame, max(counts), sampling_batch_size)
                for frame in images
            ], axis=1)
            if not volume:
                predictions = predictions[:, 0]
            hard_predictions = predictions > 0.5
            scores = {str(count): consensus_scores(truth, hard_predictions[:count])
                      for count in counts}
        else:
            hard_predictions = np.stack([
                sample_experts(model, frame, params["preference_samples"], sampling_batch_size).mean(1) > 0.5
                for frame in images
            ], axis=1)
            if not volume:
                hard_predictions = hard_predictions[:, 0]
            scores = preference_scores(truth, hard_predictions)
        mask_path = case_directory / f"{index:05d}_masks.npz"
        save_masks(mask_path, truth, hard_predictions)
        record = {"index": index, "scores": scores, "seconds": time.monotonic() - started,
                  "masks": mask_path.name, "mask_packing": "numpy.packbits, flattened, big-endian bits"}
        atomic_json(result_path, record)
        records.append(record)
        atomic_json(directory / "status.json", {
            "state": "evaluating", "completed_cases": len(records), "total_cases": total,
            "classification": params["classification"], "time": time.time(),
            "sampling_batch_size": sampling_batch_size, "gpu_util_percent": torch.cuda.utilization(),
        })
        report(directory.parents[2])
        print(f"EVAL {directory} {index + 1}/{total}: {json.dumps(scores)}", flush=True)
    if params["stage"] == 1:
        means = {str(count): {metric: float(np.mean([r["scores"][str(count)][metric] for r in records]))
                              for metric in records[0]["scores"][str(count)]}
                 for count in counts}
    else:
        each = np.mean([r["scores"]["Dice_each"] for r in records], axis=0)
        means = {"Dice_each": each.tolist(), "Dice_mean": float(each.mean())}
    atomic_json(directory / "results.json", {
        "dataset": params["dataset"], "stage": params["stage"], "fold": params["fold"],
        "classification": params["classification"], "evaluation_split": params["evaluation_split"],
        "cases": total, "metrics": means, "source_id": source_id,
        "checkpoint_sha256": sha256(directory / "final.pt"),
        "training_source_id": training_source_id, "training_batch_size": params["batch_size"],
        "training_protocol": TRAINING_PROTOCOL,
        "sample_budget": params.get("sample_budget"), "sampling_batch_size": sampling_batch_size,
        "consensus_samples": counts, "preference_samples": params["preference_samples"],
        "dice_units": "fraction", "time": time.time(),
        "ged_conventions": {"GED": "released reference: empty/empty IoU=0",
                            "GED_empty_match": "alternative: empty/empty IoU=1"},
    })
    atomic_json(directory / "status.json", {
        "state": "complete", "cases": total, "classification": params["classification"], "time": time.time(),
    })
    del model
    torch.cuda.empty_cache()


def paper_comparison(rows):
    comparison = {
        "paper": "https://arxiv.org/abs/2507.13087v2",
        "aggregation": "unweighted mean of four held-out patient folds",
        "npc": "not comparable: validation only; official test evaluation unavailable",
        "baselines_and_ablations": "not run by this queue",
    }
    source_rows = [row for row in rows
                   if row.get("classification", row.get("results", {}).get("classification", "")).startswith(
                       ("released_source_", "corrected_diffusion_slice_"))]
    if source_rows:
        comparison["source_run"] = {
            "state": "not_a_patient_disjoint_paper_comparison",
            "reason": "Released slice KFold can share patients across training and evaluation.",
            "experiments": [{key: row[key] for key in ("experiment", "state", "results") if key in row}
                            for row in source_rows],
        }
    for stage in (1, 2):
        results = [row["results"] for row in rows if "results" in row
                   and row["results"]["dataset"] == "lidc"
                   and row["results"]["stage"] == stage
                   and row["results"]["classification"] in (
                       "paper_budget_with_documented_assumptions", "gpu_optimized_sample_budget")]
        key = f"lidc_stage_{stage}"
        if {result["fold"] for result in results} != {0, 1, 2, 3}:
            comparison[key] = {"state": "incomplete", "completed_folds": len(results)}
            continue
        entries = []
        if stage == 1:
            for count, ged, dice in ((10, 0.09154, 0.9121), (30, 0.0773, 0.9220), (50, 0.0745, 0.9237)):
                for metric, target in (("GED", ged), ("Dice_soft", dice)):
                    values = [result["metrics"][str(count)][metric] for result in results]
                    entries.append({"metric": metric, "samples": count, "paper": target,
                                    "observed": float(np.mean(values)), "fold_std": float(np.std(values)),
                                    "difference": float(np.mean(values) - target)})
        else:
            targets = [0.9185, 0.9015, 0.9130, 0.9068]
            values = np.array([result["metrics"]["Dice_each"] for result in results])
            for expert, target in enumerate(targets):
                observed = float(values[:, expert].mean())
                entries.append({"metric": f"Dice_A{expert + 1}", "paper": target,
                                "observed": observed, "difference": observed - target,
                                "fold_std": float(values[:, expert].std())})
            entries.append({"metric": "Dice_mean", "paper": 0.9099,
                            "observed": float(values.mean()), "difference": float(values.mean() - 0.9099)})
        changed = any(result["classification"] == "gpu_optimized_sample_budget" for result in results)
        comparison[key] = {"state": "evaluated_with_modified_batch_size" if changed else "evaluated_with_documented_assumptions",
                           "metrics": entries,
                           "fold_batch_sizes": {str(r["fold"]): r.get("training_batch_size") for r in results}}
    return comparison


def report(output):
    rows = []
    for path in sorted(output.glob("*/fold_*/stage_*/status.json")):
        record = json.loads(path.read_text())
        result_path = path.with_name("results.json")
        if result_path.exists():
            record["results"] = json.loads(result_path.read_text())
        rows.append({"experiment": str(path.parent.relative_to(output)), **record})
    plan_path = output / "run_plan.json"
    if plan_path.exists():
        started = {row["experiment"] for row in rows}
        for job in json.loads(plan_path.read_text())["jobs"]:
            if job["experiment"] not in started:
                rows.append({**job, "state": "queued", "step": 0})
    rows.sort(key=lambda row: row["experiment"])
    atomic_json(output / "experiment_ledger.json", rows)
    comparison = paper_comparison(rows)
    atomic_json(output / "paper_comparison.json", comparison)
    source_run = "source_run" in comparison
    lines = [
        "# DiffOSeg reproduction status", "",
        ("Released-source training with paper batch size and step budgets. LIDC uses slice KFold, with patient overlap."
         if source_run else
         "Paper-budget runs and GPU-optimized sample-budget runs are labeled separately; smoke runs are engineering checks."),
        "NPC evaluation uses the 20-case validation set. The 50-case official test set/labels are missing.",
        "No claim of paper-result reproduction is made before held-out evaluation completes.",
        "", "| Experiment | State | Progress | Evidence class |", "|---|---|---|---|",
    ]
    for row in rows:
        progress = f'{row.get("step", row.get("completed_cases", row.get("cases", 0)))}/{row.get("target_steps", row.get("total_cases", row.get("cases", 0)))}'
        lines.append(f'| {row["experiment"]} | {row["state"]} | {progress} | {row.get("classification", "unavailable")} |')
    if source_run:
        lines.extend(["", "## Source-run results", "",
                      "These slice-split results are excluded from the patient-disjoint paper comparison."])
        for row in rows:
            if "results" in row:
                lines.append(f'- {row["experiment"]}: {json.dumps(row["results"]["metrics"], sort_keys=True)}')
    lines.extend(["", "## Paper comparison", "", "Four completed patient folds are required before aggregating LIDC scores."])
    for key in ("lidc_stage_1", "lidc_stage_2"):
        item = comparison[key]
        if "metrics" not in item:
            lines.append(f'- {key}: {item["completed_folds"]}/4 folds evaluated.')
            continue
        lines.extend(["", f"### {key}", "", "| Metric | Samples | Paper | Observed | Difference |", "|---|---|---|---|---|"])
        for metric in item["metrics"]:
            lines.append(f'| {metric["metric"]} | {metric.get("samples", "-")} | {metric["paper"]:.5f} | {metric["observed"]:.5f} | {metric["difference"]:+.5f} |')
    lines.extend(["", "Dice is expressed as a fraction. GED uses the released empty-mask convention; GED_empty_match is also saved with per-case masks for independent verification.",
                  "NPC formal test comparison and baseline/ablation runs remain outstanding."])
    (output / "reproduction_report.md").write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(ROOT / "configs/reproduction.yml"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--datasets", nargs="+", choices=("lidc", "npc"), default=["lidc", "npc"])
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--phase", choices=("all", "train", "evaluate"), default="all")
    parser.add_argument("--execution-profile", choices=("original", "optimized"), default="original")
    parser.add_argument("--inherit-from", help="Preserve verified completed training from a previous run")
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text())
    if config.get("training_protocol", TRAINING_PROTOCOL) != TRAINING_PROTOCOL:
        raise ValueError("Config training protocol differs from this implementation")
    config["training_protocol"] = TRAINING_PROTOCOL
    if args.execution_profile == "optimized" and not config.get("released_source"):
        raise ValueError("Optimized execution requires the released-source training protocol")
    output = Path(args.output).resolve()
    if args.smoke:
        output = output / "smoke"
    validate_run_protocol(output)
    output.mkdir(parents=True, exist_ok=True)
    if config.get("released_source"):
        # The restored train_step writes relative visual_debug files each step.
        if args.execution_profile == "optimized":
            prepare_debug_directory(output)
        else:
            (output / "visual_debug").mkdir(exist_ok=True)
        os.chdir(output)
    data_root = Path(config["data_root"])
    input_hashes = {name: sha256(data_root / name) for name in ("lidc_attributes.pkl", "MMIS2024TASK1.zip")}
    if args.inherit_from:
        if args.smoke:
            raise ValueError("Smoke runs must train their own test checkpoints")
        inherit_completed_runs(args.inherit_from, output, input_hashes)
    sizes = training_sizes(data_root, config["seed"]) if config.get("preserve_sample_budget") else None
    jobs = []
    for name in args.datasets:
        settings = config["datasets"][name]
        for fold in (settings["folds"][:1] if args.smoke else settings["folds"]):
            for stage in (1, 2):
                experiment = f"{name}/fold_{fold if fold is not None else 'official'}/stage_{stage}"
                target = settings["stage_steps"][stage - 1]
                classification = "paper_budget_with_documented_assumptions" if name == "lidc" else "paper_budget_validation_only"
                if name == "lidc" and config.get("lidc_split", "slice" if config.get("released_source") else "patient") == "slice":
                    classification = "corrected_diffusion_slice_folds"
                batch_size = config.get("stage_batch_sizes", [config["batch_size"]] * 2)[stage - 1]
                if sizes is not None:
                    budget = reference_sample_budget(sizes[name][fold], config["reference_batch_size"], target)
                    target = math.ceil(budget / batch_size)
                    classification = "gpu_optimized_sample_budget" if name == "lidc" else "gpu_optimized_validation_only"
                old_config = output / experiment / "config.json"
                if (output / experiment / "checkpoint_origin.json").exists():
                    previous_params = json.loads(old_config.read_text())
                    target, classification = previous_params["steps"], previous_params["classification"]
                jobs.append({
                    "experiment": experiment, "target_steps": 20 if args.smoke else target,
                    "classification": "engineering_smoke" if args.smoke else classification,
                })
    atomic_json(output / "run_plan.json", {"jobs": jobs, "total_training_steps": sum(j["target_steps"] for j in jobs)})
    torch.set_num_threads(config["torch_threads"])
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU required")
    torch.backends.cudnn.benchmark = True
    if "cudnn_benchmark_limit" in config:
        torch.backends.cudnn.benchmark_limit = config["cudnn_benchmark_limit"]
    source_id = snapshot(output)
    atomic_json(output / "environment.json", {
        "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "source_id": source_id, "torch": torch.__version__, "cuda": torch.version.cuda,
        "training_protocol": TRAINING_PROTOCOL,
        "gpu": torch.cuda.get_device_name(), "uv_lock_sha256": sha256(ROOT / "uv.lock"),
        "released_source": config.get("released_source", False),
        "lidc_split": config.get("lidc_split", "slice" if config.get("released_source") else "patient"),
        "source_base_commit": config.get("source_base_commit"),
        "execution_profile": args.execution_profile,
        "packages": {d.metadata["Name"]: d.version for d in distributions()},
    })
    atomic_json(output / "input_hashes.json", input_hashes)
    current = None
    atomic_json(output / "pipeline_status.json", {
        "state": "running", "datasets": args.datasets, "smoke": args.smoke, "phase": args.phase,
        "source_id": source_id, "time": time.time(),
    })
    try:
        for name in args.datasets:
            settings = config["datasets"][name]
            folds = settings["folds"][:1] if args.smoke else settings["folds"]
            if config.get("released_source"):
                # Match the released per-stage fold order; evaluate after training.
                tasks = [(fold, stage, phase) for phase in ("train", "evaluate")
                         for stage in (1, 2) for fold in folds]
            else:
                tasks = [(fold, stage, phase) for fold in folds
                         for stage, phase in ((1, "train"), (2, "train"), (1, "evaluate"), (2, "evaluate"))]
            for fold, stage, phase in tasks:
                if args.phase != "all" and phase != args.phase:
                    continue
                fold_directory = output / name / f"fold_{fold if fold is not None else 'official'}"
                current = fold_directory / f"stage_{stage}"
                current.mkdir(parents=True, exist_ok=True)
                train, evaluation, metadata = datasets_for_run(
                    config["data_root"], name, stage, fold, config["seed"],
                    released_source=config.get("released_source", False), lidc_split=config.get("lidc_split"))
                if config.get("released_source") and name == "lidc" and phase == "train" and fold == folds[0]:
                    # run_train seeds/shuffles once before all folds of each stage.
                    np.random.seed(1337)
                    indices = list(range(len(train.dataset)))
                    np.random.shuffle(indices)
                params = {key: value for key, value in config.items() if key != "datasets"}
                params.update({
                    "dataset": name, "dataset_file": "datasets.lidc" if name == "lidc" else "datasets.npc_170",
                    "stage": stage, "fold": fold, "distributed": False, "multigpu": False,
                    "steps": settings["stage_steps"][stage - 1],
                    "consensus_samples": settings["consensus_samples"],
                    "evaluation_vote_strategy": "confidence",
                    "run_seed": config["seed"] + (fold or 0),
                    "evaluation_split": metadata["evaluation_split"],
                    "classification": "paper_budget_with_documented_assumptions" if name == "lidc" else "paper_budget_validation_only",
                })
                params["batch_size"] = config.get("stage_batch_sizes", [config["batch_size"]] * 2)[stage - 1]
                if metadata["evaluation_split"] == "held_out_slices":
                    params["classification"] = "corrected_diffusion_slice_folds"
                if config.get("preserve_sample_budget"):
                    params["reference_steps"] = params["steps"]
                    params["sample_budget"] = reference_sample_budget(len(train), config["reference_batch_size"], params["steps"])
                    params["steps"] = math.ceil(params["sample_budget"] / params["batch_size"])
                    params["classification"] = "gpu_optimized_sample_budget" if name == "lidc" else "gpu_optimized_validation_only"
                if args.smoke:
                    params.update(steps=20, log_every=10, checkpoint_every=20,
                                  consensus_samples=[4], preference_samples=4,
                                  evaluation_cases=1, evaluation_slices=1,
                                  classification="engineering_smoke")
                    if "sample_budget" in params:
                        params["sample_budget"] = params["batch_size"] * 20 - 7
                config_path = current / "config.json"
                if (current / "checkpoint_origin.json").exists():
                    params = json.loads(config_path.read_text())
                if config_path.exists() and json.loads(config_path.read_text()) != params:
                    raise ValueError(f"Existing experiment config differs: {config_path}")
                atomic_json(config_path, params)
                atomic_json(current / "split.json", metadata)
                atomic_json(current / "execution.json", {
                    "runtime_source_id": source_id, "sampling_batch_size": config["sampling_batch_size"],
                    "training_batch_size": params["batch_size"], "phase": phase,
                    "execution_profile": args.execution_profile,
                    "fixed_alpha_foreach_ema": args.execution_profile == "optimized",
                    "raw_npc_cache": args.execution_profile == "optimized" and name == "npc",
                    "debug_directory": str((output / "visual_debug").resolve()),
                })
                if phase == "train":
                    train_experiment(params, train, current, source_id, fold_directory / "stage_1/final.pt",
                                     execution_profile=args.execution_profile)
                else:
                    evaluate_experiment(params, train, evaluation, current, source_id,
                                        sampling_batch_size=config["sampling_batch_size"])
                report(output)
                del train, evaluation
        atomic_json(output / "pipeline_status.json", {
            "state": ("training_complete" if args.phase == "train"
                      else "complete" if args.smoke else "main_runs_complete"), "source_id": source_id,
            "evaluation": "pending" if args.phase == "train" else "complete",
            "formal_npc_test": "blocked: test images and ground-truth/evaluation unavailable",
            "time": time.time(),
        })
    except BaseException as error:
        status = {"state": "failed", "error": str(error), "traceback": traceback.format_exc(),
                  "experiment": str(current), "time": time.time()}
        if current is not None:
            atomic_json(current / "failure.json", status)
            prior = json.loads((current / "status.json").read_text()) if (current / "status.json").exists() else {}
            atomic_json(current / "status.json", {**prior, "state": "failed", "error": str(error)})
        atomic_json(output / "pipeline_status.json", status)
        raise
    finally:
        report(output)
        if args.execution_profile == "optimized":
            shutil.copytree(output / "visual_debug", output / "debug_snapshot", dirs_exist_ok=True)


if __name__ == "__main__":
    main()
