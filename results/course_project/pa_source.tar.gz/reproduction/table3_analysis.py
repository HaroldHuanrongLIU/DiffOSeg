"""Paired seed-by-patient bootstrap for the frozen Table 3 comparison."""
import numpy as np


METRICS = ("GED", "Dice_soft")


def classify(intervals):
    ged, dice = np.asarray(intervals)
    if ged[1] < 0 and dice[0] > 0:
        return "supported"
    if ged[0] > 0 or dice[1] < 0:
        return "not_supported"
    return "inconclusive"


def paired_bootstrap(p, a, patient_ids, nboot=10000, seed=271828, sample_seeds=True):
    p, a = np.asarray(p, dtype=float), np.asarray(a, dtype=float)
    if p.shape != a.shape or p.ndim != 3 or p.shape[2] != 2:
        raise ValueError("Expected aligned [training seed, slice, two metrics] arrays")
    if len(patient_ids) != p.shape[1] or not np.isfinite([p, a]).all():
        raise ValueError("Invalid patient mapping or nonfinite scores")
    patients, inverse = np.unique(patient_ids, return_inverse=True)
    nseeds, npatients = p.shape[0], len(patients)
    counts = np.bincount(inverse)
    differences = p - a
    sums = np.stack([differences[:, inverse == i].sum(axis=1)
                     for i in range(npatients)], axis=1)
    rng = np.random.default_rng(seed)
    seed_weights = (rng.multinomial(nseeds, np.ones(nseeds) / nseeds, size=nboot)
                    if sample_seeds else np.ones((nboot, nseeds), dtype=int))
    patient_weights = rng.multinomial(npatients, np.ones(npatients) / npatients, size=nboot)
    boot = np.einsum("bs,spm,bp->bm", seed_weights, sums, patient_weights, optimize=True)
    boot /= (nseeds * (patient_weights @ counts))[:, None]
    intervals = np.quantile(boot, [0.025, 0.975], axis=0).T
    return {
        "metrics": list(METRICS), "difference_definition": "P minus A",
        "P_per_seed": p.mean(axis=1).tolist(), "A_per_seed": a.mean(axis=1).tolist(),
        "P_mean": p.mean(axis=(0, 1)).tolist(), "A_mean": a.mean(axis=(0, 1)).tolist(),
        "difference": differences.mean(axis=(0, 1)).tolist(),
        "difference_ci95": intervals.tolist(), "decision": classify(intervals),
        "nboot": nboot, "bootstrap_seed": seed, "sample_seeds": sample_seeds,
        "patients": npatients, "slices": p.shape[1], "training_seeds": nseeds,
        "aggregation": "slice mean within seed, then equal mean over training seeds",
        "resampling": "paired seed and patient weights; retain every slice of each sampled patient",
        "limitation": "Three training seeds provide a limited estimate of training variability.",
    }
