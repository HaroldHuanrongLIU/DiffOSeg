"""Isolated GPU performance measurements; these are not paper experiments."""
import argparse
import copy
import json
from pathlib import Path
import statistics
import threading
import time

import pynvml
import torch
from torch.utils.data import DataLoader

from ddpm.polyak import PolyakAverager
from ddpm.trainer import Trainer
from reproduction.performance import ForeachEMA
from reproduction.data import datasets_for_run
from reproduction.run import atomic_json, model_for, sample_foreground, seed_all


class Monitor:
    def __init__(self):
        pynvml.nvmlInit()
        self.handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        self.samples = []
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self.poll, daemon=True)

    def poll(self):
        while not self.stop.is_set():
            usage = pynvml.nvmlDeviceGetUtilizationRates(self.handle)
            memory = pynvml.nvmlDeviceGetMemoryInfo(self.handle)
            self.samples.append((usage.gpu, memory.used / 2**30))
            self.stop.wait(0.1)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.stop.set()
        self.thread.join()

    def result(self):
        return {"gpu_util_mean": statistics.mean(s[0] for s in self.samples),
                "gpu_util_max": max(s[0] for s in self.samples),
                "device_memory_mean_gib": statistics.mean(s[1] for s in self.samples),
                "device_memory_max_gib": max(s[1] for s in self.samples)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["baseline", "foreach", "fused", "compiled"], default="baseline")
    parser.add_argument("--phase", choices=["train", "evaluate"], default="train")
    parser.add_argument("--stage", type=int, default=1)
    parser.add_argument("--steps", type=int, default=150)
    parser.add_argument("--batch-size", type=int, default=12)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--dataset", choices=["lidc", "npc"], default="lidc")
    parser.add_argument("--sampling-batch", type=int, default=12)
    parser.add_argument("--eval-images", type=int, default=1)
    parser.add_argument("--output", required=True)
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()
    checkpoint_dir = Path("/mnt/hdd1/phd_course/cisc8006/DiffOSeg_runs/20260910_paper_v2/lidc/fold_0/stage_1")
    params = json.loads((checkpoint_dir / "config.json").read_text())
    params["stage"] = args.stage
    params["batch_size"] = args.batch_size
    params["dataset_file"] = "datasets.lidc" if args.dataset == "lidc" else "datasets.npc_170"
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.benchmark_limit = 5
    seed_all(1337)
    train, evaluation, _ = datasets_for_run(params["data_root"], args.dataset, args.stage,
                                           0 if args.dataset == "lidc" else None, params["seed"])
    model = model_for(params, train)
    state = torch.load(checkpoint_dir / "final.pt", map_location="cpu", weights_only=False)
    weights = state["model"] if args.phase == "train" else state["average_model"]
    current = model.unet.state_dict()
    model.unet.load_state_dict({k: v for k, v in weights.items()
                               if k in current and v.shape == current[k].shape}, strict=False)
    del state, weights, current
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    timings = []
    waits = []
    if args.phase == "train":
        average = copy.deepcopy(model)
        polyak = (PolyakAverager(model, average, params["polyak_alpha"]) if args.mode == "baseline"
                  else ForeachEMA(model, average, params["polyak_alpha"]))
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-4,
                                     **({"fused": True} if args.mode in ("fused", "compiled") else {}))
        trainer = Trainer(polyak, optimizer, None, torch.ones(2, device="cuda"), None, None, params)
        loader = DataLoader(train, batch_size=args.batch_size, shuffle=True, num_workers=args.workers,
                            pin_memory=True, persistent_workers=True, drop_last=True)
        iterator = iter(loader)
        if args.mode == "compiled":
            model.unet.compile(mode="reduce-overhead", dynamic=False)
        print(f"WARMUP train stage={args.stage} mode={args.mode}", flush=True)
        batch = next(iterator)
        for _ in range(20):
            trainer.train_step(None, batch)
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        print("MEASURE", flush=True)
        with Monitor() as monitor:
            started = time.perf_counter()
            for _ in range(args.steps):
                before = time.perf_counter()
                try:
                    batch = next(iterator)
                except StopIteration:
                    iterator = iter(loader)
                    batch = next(iterator)
                waits.append(time.perf_counter() - before)
                before = time.perf_counter()
                result = trainer.train_step(None, batch)
                timings.append(time.perf_counter() - before)
            torch.cuda.synchronize()
            elapsed = time.perf_counter() - started
        if args.profile:
            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                                   torch.profiler.ProfilerActivity.CUDA],
                                        record_shapes=True) as profile:
                for _ in range(5):
                    trainer.train_step(None, batch)
            table = profile.key_averages().table(sort_by="self_cpu_time_total", row_limit=25)
            output.with_suffix(".profile.txt").write_text(table)
            profile.export_chrome_trace(str(output.with_suffix(".trace.json")))
        result = {"phase": "train", "mode": args.mode, "stage": args.stage, "steps": args.steps,
                  "elapsed_seconds": elapsed, "steps_per_second": args.steps / elapsed,
                  "images_per_second": args.batch_size * args.steps / elapsed,
                  "data_wait_mean_ms": statistics.mean(waits) * 1000,
                  "train_step_mean_ms": statistics.mean(timings) * 1000, "last_loss": result["loss"]}
    else:
        model.eval()
        if args.mode == "compiled":
            model.unet.compile(mode="reduce-overhead", dynamic=False)
        image, _ = evaluation[0]
        print(f"WARMUP eval mode={args.mode} sampling_batch={args.sampling_batch}", flush=True)
        sample_foreground(model, image, 50 * args.eval_images, args.sampling_batch,
                          expert=0 if args.stage == 2 else None)
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        with Monitor() as monitor:
            started = time.perf_counter()
            for _ in range(3):
                sample_foreground(model, image, 50 * args.eval_images, args.sampling_batch,
                                  expert=0 if args.stage == 2 else None)
            elapsed = time.perf_counter() - started
        result = {"phase": "evaluate", "mode": args.mode, "stage": args.stage,
                  "sampling_batch_size": args.sampling_batch,
                  "eval_images": args.eval_images,
                  "seconds_per_50_samples": elapsed / (3 * args.eval_images), "elapsed_seconds": elapsed}
    result.update(monitor.result())
    result.update({"dataset": args.dataset, "batch_size": args.batch_size,
                   "num_workers": args.workers, "cudnn_benchmark_limit": 5})
    result.update({"allocated_gib": torch.cuda.memory_allocated() / 2**30,
                   "reserved_gib": torch.cuda.memory_reserved() / 2**30,
                   "peak_allocated_gib": torch.cuda.max_memory_allocated() / 2**30,
                   "classification": "isolated_performance_benchmark"})
    atomic_json(output, result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
