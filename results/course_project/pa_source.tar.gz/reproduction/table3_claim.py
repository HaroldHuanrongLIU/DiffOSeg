"""Frozen, paired P/A Stage-I experiment; reuses the audited training/evaluation path."""
import argparse
import copy
from datetime import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pickle
import shutil
import subprocess
import sys
import time
import traceback
from unittest.mock import patch

import numpy as np
import torch
from torch.utils.data import Subset
import yaml

from datasets.lidc import LIDC_IDRI, transform as released_lidc_transform
from reproduction import run
from reproduction.data import datasets_for_run, patient_folds
from reproduction.execution import prepare_debug_directory
from reproduction.table3_analysis import METRICS, paired_bootstrap

SEEDS = (20261, 20262, 20263)
SPLIT_SEED, FOLD = 1337, 0
GPU_BUDGET_SECONDS = 240 * 3600
JOB_ORDER = (("P", 20261), ("A", 20261), ("A", 20262),
             ("P", 20262), ("P", 20263), ("A", 20263))


class AverageLIDC(LIDC_IDRI):
    def _generate_probabilistic_weights(self):
        # Consume the P draws as well, preserving paired augmentation/random streams.
        super()._generate_probabilistic_weights()
        return np.ones(self.num_experts, dtype=np.float32)


def claim_transform(image, labels):
    image, labels = released_lidc_transform(image, labels)
    factor = float(np.random.uniform(0.9, 1.1))
    return (image * factor).clamp(0, 1), labels


def worker_parameters(base, condition, seed, smoke):
    params = copy.deepcopy({k: v for k, v in base.items() if k != "datasets"})
    params.update(dataset="lidc", dataset_file="datasets.lidc", stage=1, fold=FOLD,
                  distributed=False, multigpu=False, condition=condition,
                  seed=SPLIT_SEED, training_seed=seed, run_seed=1000000 + seed * 1000,
                  steps=20 if smoke else 120000, consensus_samples=[30],
                  sampling_batch_size=30, evaluation_vote_strategy="confidence",
                  evaluation_split="training_only_smoke" if smoke else "held_out_patients",
                  classification="engineering_smoke" if smoke else "scaled_faithful_table3_with_disclosed_choices",
                  log_every=10 if smoke else 1000, checkpoint_every=20 if smoke else 5000,
                  claim_protocol="table3_pa_fixed_fold_three_seeds_v1")
    if smoke:
        params["evaluation_cases"] = 2
    return params


def write_once(path, value):
    if path.exists():
        if json.loads(path.read_text()) != value:
            raise ValueError(f"Frozen record differs: {path}")
    else:
        run.atomic_json(path, value)


def prepare(output):
    if output.exists():
        raise ValueError("Choose a new claim run directory")
    output.mkdir(parents=True)
    base = yaml.safe_load((run.ROOT / "configs/reproduction_source.yml").read_text())
    base["datasets"] = {"lidc": base["datasets"]["lidc"]}
    data_path = Path(base["data_root"]) / "lidc_attributes.pkl"
    with data_path.open("rb") as stream:
        data = pickle.load(stream)
    ids = [str(v["series_uid"]) for v in data.values()]
    split = patient_folds(ids, SPLIT_SEED)[FOLD]
    assert not set(split["train_patients"]) & set(split["test_patients"])
    split.update(dataset="lidc", fold=FOLD, evaluation_split="held_out_patients",
                 test_series_uids=[ids[i] for i in split["test_indices"]],
                 test_patient_ids=[ids[i].split("_")[0] for i in split["test_indices"]])
    protocol = {
        "created_at": datetime.now().astimezone().isoformat(),
        "claim": "P has lower GED30 and higher DiceSoft30 than A on one frozen LIDC patient fold",
        "registration": "Local protocol freeze before this paired comparison; not an external registry",
        "prior_exposure": "Earlier P-only corrected runs evaluated all four folds. Fold 0 is the fixed first fold, not selected by performance. Historical results are pilot evidence only.",
        "split_seed": SPLIT_SEED, "fold": FOLD, "training_seeds": list(SEEDS),
        "training_jobs": 6, "steps_per_job": 120000, "batch_size": 12,
        "training_rng": "Seed Python, NumPy, Torch CPU and CUDA before data sample/model construction; same seed within each P/A pair",
        "evaluation_seed": "1000000 + training_seed * 1000 + heldout slice index",
        "P": "Uniform subset size 1..4, uniform subset of that size, average selected binary masks",
        "A": "Average all four binary masks; consume unused P subset draws to preserve paired RNG",
        "common_label_encoding": "Per-pixel categorical sample from [1-p,p] before forward diffusion and KL target; disclosed interpretation, not fully specified in paper",
        "common_corrections": ["Uniform training t in 1..250", "Cumulative cosine alpha from cumprod",
                               "Preserve fractional consensus", "Unit-range inputs", "Patient-disjoint folds"],
        "data_transforms": "Unit-range 128x128, released random flips and 90-degree rotations, shared intensity multiplier Uniform[0.9,1.1] clipped to [0,1]. Paper specifies intensity scaling but not its range; this range is a frozen implementation assumption.",
        "optimizer": "Existing released Adam and polynomial LR construction; EMA alpha=0.9999",
        "checkpoint": "Final EMA at exactly 120000 updates; no heldout checkpoint selection",
        "evaluation": {"diffusion_steps": 250, "samples_per_slice": 30, "sampling_batch_size": 30,
                       "labels": "all four expert masks", "prediction_threshold": 0.5,
                       "dice_thresholds": [0.1, 0.3, 0.5, 0.7, 0.9],
                       "GED": "Released empirical V-statistic with IoU=0 for empty/empty; alternative convention reported separately",
                       "aggregation": "Unweighted slice mean within the single fold, then equal mean across seeds"},
        "statistics": {"method": "paired seed-by-patient multi-bootstrap", "replicates": 10000,
                       "seed": 271828, "CI": "two-sided percentile 95%",
                       "difference": "P minus A",
                       "supported": "GED CI upper < 0 and Dice CI lower > 0",
                       "not_supported": "GED CI lower > 0 or Dice CI upper < 0",
                       "otherwise": "inconclusive",
                       "secondary": "Patient-only paired bootstrap conditional on the three seeds, and alternative empty-mask GED"},
        "budget": {"max_gpus": 2, "actual_host_gpus": 1, "gpu_hours": 240,
                   "accounting": "Sum elapsed time of allocated single-GPU worker processes, including smoke/evaluation/failures; waiting excluded"},
        "job_order": [list(x) for x in JOB_ORDER],
        "paper_reference": {"P": {"GED30": 0.0773, "DiceSoft30": 0.9220},
                            "A": {"GED30": 0.1029, "DiceSoft30": 0.9043}},
        "limits": ["Single previously examined fold", "Three seeds", "Disclosed common implementation interpretations",
                   "No paper absolute-value matching requirement", "Budget exhaustion or incomplete paired runs cannot support claim"],
    }
    run.atomic_json(output / "protocol.json", protocol)
    run.atomic_json(output / "split.json", split)
    run.atomic_json(output / "base_config.json", base)
    run.atomic_json(output / "inputs.json", {"lidc_attributes.pkl": run.sha256(data_path)})
    (output / "baseline_worktree_status.txt").write_text(subprocess.check_output(
        ["git", "status", "--short"], cwd=run.ROOT, text=True))
    source = output / "source"
    source.mkdir()
    for name in ("ddpm", "datasets", "reproduction", "configs", "tests", "scripts"):
        shutil.copytree(run.ROOT / name, source / name,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    for name in ("uv.lock", "pyproject.toml", "INSTALL.md", "params.yml", "metrics_set.py"):
        shutil.copy2(run.ROOT / name, source / name)
    source_id = run.snapshot(output)
    run.atomic_json(output / "freeze.json", {
        "source_id": source_id, "protocol_sha256": run.sha256(output / "protocol.json"),
        "split_sha256": run.sha256(output / "split.json"),
        "base_config_sha256": run.sha256(output / "base_config.json"),
        "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=run.ROOT, text=True).strip(),
        "source": str(source), "python": sys.executable,
        "dependency_hashes": {"metrics_set.py": run.sha256(source / "metrics_set.py")},
    })
    run.atomic_json(output / "pipeline_status.json", {"state": "prepared", "time": time.time()})
    print(output, flush=True)


def verify_freeze(output):
    frozen = json.loads((output / "freeze.json").read_text())
    for name, expected in frozen["dependency_hashes"].items():
        if run.sha256(run.ROOT / name) != expected:
            raise ValueError(f"Frozen dependency changed: {name}")
    for name in ("protocol", "split", "base_config"):
        if run.sha256(output / f"{name}.json") != frozen[f"{name}_sha256"]:
            raise ValueError(f"Frozen {name} changed")
    if run.snapshot(output) != frozen["source_id"]:
        raise ValueError("Frozen source changed")
    return frozen


def job_directory(output, condition, seed, smoke=False):
    return output / ("preflight" if smoke else "runs") / condition / f"seed_{seed}" / "lidc/fold_0/stage_1"


def tensor_digest(model):
    digest = hashlib.sha256()
    for name, value in model.unet.state_dict().items():
        digest.update(name.encode())
        digest.update(value.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def worker(output, condition, seed, phase, smoke):
    frozen = verify_freeze(output)
    base = json.loads((output / "base_config.json").read_text())
    params = worker_parameters(base, condition, seed, smoke)
    directory = job_directory(output, condition, seed, smoke)
    directory.mkdir(parents=True, exist_ok=True)
    root = directory.parents[2]
    prepare_debug_directory(root)
    os.chdir(root)
    torch.set_num_threads(base["torch_threads"])
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    train, evaluation, metadata = datasets_for_run(
        base["data_root"], "lidc", 1, FOLD, SPLIT_SEED, released_source=True, lidc_split="patient")
    split = json.loads((output / "split.json").read_text())
    for key in metadata:
        if metadata[key] != split[key]:
            raise ValueError(f"Worker split differs: {key}")
    train.dataset.transform = claim_transform
    if condition == "A":
        train.dataset.__class__ = AverageLIDC
    if smoke:
        evaluation = Subset(evaluation.dataset, split["train_indices"][:2])
    write_once(directory / "config.json", params)
    write_once(directory / "split.json", metadata)
    run.atomic_json(directory / "execution.json", {
        "source_id": frozen["source_id"], "phase": phase, "deterministic_algorithms": True,
        "cudnn_benchmark": False, "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "torch": torch.__version__, "cuda": torch.version.cuda, "gpu": torch.cuda.get_device_name(),
        "training_seed": seed, "evaluation_seed": params["run_seed"],
    })
    try:
        if phase in ("train", "all"):
            run.seed_all(seed)
            original = run._build_model
            hashes = []
            def record_initialization(*args, **kwargs):
                model = original(*args, **kwargs)
                hashes.append(tensor_digest(model))
                return model
            with patch.object(run, "_build_model", record_initialization):
                run.train_experiment(params, train, directory, frozen["source_id"],
                                     directory / "unused_stage1.pt", execution_profile="optimized")
            if hashes:
                write_once(directory / "initial_weights.json", {"training_seed": seed, "sha256": hashes})
        if phase in ("evaluate", "all"):
            run.evaluate_experiment(params, train, evaluation, directory, frozen["source_id"], 30)
    except BaseException:
        run.atomic_json(directory / "failure.json", {"time": time.time(), "traceback": traceback.format_exc()})
        raise


def check_pair_initialization(output, seed, smoke=False):
    paths = [job_directory(output, c, seed, smoke) / "initial_weights.json" for c in ("P", "A")]
    if all(p.exists() for p in paths):
        if paths[0].read_text() != paths[1].read_text():
            raise ValueError(f"Paired initial weights differ for seed {seed}")


def gpu_snapshot():
    result = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=index,name,memory.free,memory.used,utilization.gpu",
         "--format=csv,noheader,nounits"], text=True)
    rows = []
    for line in result.strip().splitlines():
        index, name, free, used, utilization = [x.strip() for x in line.split(",")]
        rows.append(dict(index=int(index), name=name, free_mib=int(free), used_mib=int(used),
                         utilization=int(utilization)))
    return rows


def consumed_seconds(output):
    path = output / "gpu_usage.jsonl"
    return sum(json.loads(line)["gpu_seconds"] for line in path.read_text().splitlines()) if path.exists() else 0.


def launch_worker(output, condition, seed, phase, smoke):
    directory = job_directory(output, condition, seed, smoke)
    if (directory / ("final.pt" if phase == "train" else "results.json")).exists():
        return
    while True:
        snapshots = gpu_snapshot()
        eligible = [g for g in snapshots if "RTX 5090" in g["name"] and g["free_mib"] >= 20480]
        if eligible:
            gpu = max(eligible, key=lambda g: g["free_mib"])
            break
        run.atomic_json(output / "pipeline_status.json",
                        {"state": "waiting_for_gpu", "minimum_free_mib": 20480,
                         "gpu": snapshots, "time": time.time()})
        time.sleep(30)
    spent = consumed_seconds(output)
    if spent >= GPU_BUDGET_SECONDS:
        raise RuntimeError("240 GPU-hour budget exhausted before completing the claim")
    directory.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, "-u", "-B", "-m", "reproduction.table3_claim", "worker",
               "--output", str(output), "--condition", condition, "--seed", str(seed), "--phase", phase]
    if smoke:
        command.append("--smoke")
    environment = os.environ.copy()
    environment.update(CUDA_VISIBLE_DEVICES=str(gpu["index"]), PYTHONDONTWRITEBYTECODE="1",
                       CUBLAS_WORKSPACE_CONFIG=":4096:8", OMP_NUM_THREADS="4",
                       OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="4")
    log_path = directory / f"{phase}.log"
    started, start_mono = time.time(), time.monotonic()
    with log_path.open("a", buffering=1) as log:
        process = subprocess.Popen(command, cwd=run.ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
        job = {"condition": condition, "seed": seed, "phase": phase, "smoke": smoke,
               "pid": process.pid, "gpu": gpu, "started": started, "log": str(log_path)}
        run.atomic_json(output / "active_worker.json", job)
        while process.poll() is None:
            elapsed = time.monotonic() - start_mono
            run.atomic_json(output / "pipeline_status.json", {
                "state": "running", **job, "gpu_hours_total": (spent + elapsed) / 3600,
                "time": time.time()})
            if spent + elapsed >= GPU_BUDGET_SECONDS:
                process.terminate()
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    process.kill()
                break
            time.sleep(10)
        code = process.wait()
    elapsed = time.monotonic() - start_mono
    with (output / "gpu_usage.jsonl").open("a") as stream:
        stream.write(json.dumps({**job, "exit_code": code, "gpu_seconds": elapsed,
                                 "finished": time.time()}) + "\n")
    run.atomic_json(output / "active_worker.json", {**job, "state": "exited", "exit_code": code})
    if code:
        raise RuntimeError(f"Worker failed ({code}); inspect {log_path}")
    check_pair_initialization(output, seed, smoke)


def summarize(output):
    frozen = verify_freeze(output)
    split = json.loads((output / "split.json").read_text())
    values, alternative, evidence = {}, {}, []
    for condition in ("P", "A"):
        values[condition], alternative[condition] = [], []
        for seed in SEEDS:
            directory = job_directory(output, condition, seed)
            result = json.loads((directory / "results.json").read_text())
            params = json.loads((directory / "config.json").read_text())
            checkpoint = run.read_checkpoint(directory / "final.pt", frozen["source_id"],
                hashlib.sha256(json.dumps(params, sort_keys=True).encode()).hexdigest())
            assert checkpoint["step"] == 120000
            del checkpoint
            assert result["cases"] == len(split["test_indices"])
            assert result["consensus_samples"] == [30]
            assert result["checkpoint_sha256"] == run.sha256(directory / "final.pt")
            rows, alt_rows = [], []
            for index in range(len(split["test_indices"])):
                record = json.loads((directory / "cases" / f"{index:05d}.json").read_text())
                truth, predictions = run.load_masks(directory / "cases" / record["masks"])
                assert predictions.shape == (30, 128, 128) and truth.shape == (4, 128, 128)
                scores = run.consensus_scores(truth, predictions)
                for metric in (*METRICS, "GED_empty_match"):
                    if not np.isclose(scores[metric], record["scores"]["30"][metric], atol=1e-7, rtol=0):
                        raise ValueError(f"Mask metric mismatch: {directory}, case {index}, {metric}")
                rows.append([scores[k] for k in METRICS])
                alt_rows.append([scores["GED_empty_match"], scores["Dice_soft"]])
            rows = np.asarray(rows)
            np.testing.assert_allclose(rows.mean(0), [result["metrics"]["30"][k] for k in METRICS],
                                       atol=1e-7, rtol=0)
            values[condition].append(rows)
            alternative[condition].append(alt_rows)
            evidence.append({"condition": condition, "seed": seed, "cases": len(rows),
                             "checkpoint_sha256": result["checkpoint_sha256"], "verified": True})
    for seed in SEEDS:
        for condition in ("P", "A"):
            if not (job_directory(output, condition, seed) / "initial_weights.json").is_file():
                raise ValueError("Missing paired initialization evidence")
        check_pair_initialization(output, seed)
    main = paired_bootstrap(values["P"], values["A"], split["test_patient_ids"])
    secondary = paired_bootstrap(values["P"], values["A"], split["test_patient_ids"], sample_seeds=False)
    alt = paired_bootstrap(alternative["P"], alternative["A"], split["test_patient_ids"])
    summary = {"completed_at": datetime.now().astimezone().isoformat(),
               "primary": main, "conditional_patient_only": secondary, "alternative_ged": alt,
               "verification": evidence, "training_seeds": list(SEEDS),
               "gpu_hours": consumed_seconds(output) / 3600,
               "scope": "Fixed previously examined patient fold; corrected common implementation with disclosed assumptions",
               "protocol_sha256": frozen["protocol_sha256"]}
    run.atomic_json(output / "final_results.json", summary)
    lines = ["# Table 3 P/A claim result", "", f"Decision: **{main['decision']}**", "",
             "| Seed | P GED30 | A GED30 | P DiceSoft30 (%) | A DiceSoft30 (%) |",
             "|---|---:|---:|---:|---:|"]
    for i, seed in enumerate(SEEDS):
        p, a = main["P_per_seed"][i], main["A_per_seed"][i]
        lines.append(f"| {seed} | {p[0]:.6f} | {a[0]:.6f} | {100*p[1]:.4f} | {100*a[1]:.4f} |")
    lines += ["", "Paired differences are P minus A. Intervals use 10,000 paired seed-by-patient bootstrap draws.",
              f"- GED30: {main['difference'][0]:.6f}; 95% CI {main['difference_ci95'][0]}",
              f"- DiceSoft30 (fraction): {main['difference'][1]:.6f}; 95% CI {main['difference_ci95'][1]}",
              f"- GPU hours, including preflight and evaluation: {summary['gpu_hours']:.3f}",
              "", "This single-fold result does not establish the paper's four-fold scores. Three seeds limit inference.",
              "All earlier P-only evaluations are disclosed pilot work. The local protocol was frozen before this P/A comparison.",
              "Shared implementation choices, including the assumed intensity scaling range, are disclosed in protocol.json.",
              "Independent mask recomputation, checkpoint identity and paired initialization checks passed for all six runs."]
    (output / "final_report.md").write_text("\n".join(lines) + "\n")
    run.atomic_json(output / "pipeline_status.json", {"state": "complete",
        "decision": main["decision"], "gpu_hours_total": summary["gpu_hours"], "time": time.time()})


def coordinate(output):
    verify_freeze(output)
    with (output / "controller.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        run.atomic_json(output / "controller.json", {"pid": os.getpid(), "started": time.time()})
        # Never launch a duplicate if a previous controller disappeared.
        active_path = output / "active_worker.json"
        if active_path.exists():
            active = json.loads(active_path.read_text())
            if active.get("state") != "exited":
                raise RuntimeError("Previous worker/accounting is unsettled; inspect before resuming")
        try:
            base = json.loads((output / "base_config.json").read_text())
            expected = json.loads((output / "inputs.json").read_text())["lidc_attributes.pkl"]
            if run.sha256(Path(base["data_root"]) / "lidc_attributes.pkl") != expected:
                raise ValueError("Frozen LIDC bytes changed")
            for condition in ("P", "A"):
                launch_worker(output, condition, SEEDS[0], "all", True)
            states = [run.read_checkpoint(job_directory(output, c, SEEDS[0], True) / "final.pt",
                                         json.loads((output / "freeze.json").read_text())["source_id"])
                      for c in ("P", "A")]
            for key in ("rng_python",):
                if states[0][key] != states[1][key]:
                    raise ValueError("Preflight paired Python RNG differs")
            np.testing.assert_array_equal(states[0]["rng_numpy"][1], states[1]["rng_numpy"][1])
            if states[0]["rng_numpy"][2:] != states[1]["rng_numpy"][2:]:
                raise ValueError("Preflight paired NumPy RNG differs")
            for key in ("rng_torch",):
                if not torch.equal(states[0][key], states[1][key]):
                    raise ValueError("Preflight paired Torch RNG differs")
            for left, right in zip(states[0]["rng_cuda"], states[1]["rng_cuda"]):
                if not torch.equal(left, right):
                    raise ValueError("Preflight paired CUDA RNG differs")
            run.atomic_json(output / "preflight_verification.json", {
                "paired_initial_weights": True, "paired_rng_after_20_steps": True,
                "evaluation": "two training slices only, 30 samples each",
                "frozen_data_sha256": expected, "time": time.time()})
            del states
            for phase in ("train", "evaluate"):
                for condition, seed in JOB_ORDER:
                    launch_worker(output, condition, seed, phase, False)
            summarize(output)
        except BaseException:
            run.atomic_json(output / "pipeline_status.json",
                            {"state": "failed", "time": time.time(), "traceback": traceback.format_exc(),
                             "gpu_hours_total": consumed_seconds(output) / 3600})
            raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "run", "worker", "summarize"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--condition", choices=("P", "A"))
    parser.add_argument("--seed", type=int, choices=SEEDS, default=SEEDS[0])
    parser.add_argument("--phase", choices=("train", "evaluate", "all"), default="all")
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    if args.action == "prepare":
        prepare(output)
    elif args.action == "run":
        coordinate(output)
    elif args.action == "summarize":
        summarize(output)
    else:
        if args.condition is None:
            parser.error("--condition is required for a worker")
        worker(output, args.condition, args.seed, args.phase, args.smoke)


if __name__ == "__main__":
    main()
