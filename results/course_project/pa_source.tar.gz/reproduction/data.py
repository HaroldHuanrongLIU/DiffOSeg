from pathlib import Path
import pickle

import numpy as np
from torch.utils.data import Subset

from datasets import lidc, npc_170


def training_sizes(data_root, seed):
    root = Path(data_root)
    with (root / "lidc_attributes.pkl").open("rb") as stream:
        data = pickle.load(stream)
    folds = patient_folds([value["series_uid"] for value in data.values()], seed)
    return {"lidc": {i: len(fold["train_indices"]) for i, fold in enumerate(folds)},
            "npc": {None: len(list((root / "MMIS2024TASK1/training_2d").glob("*.h5")))}}


def patient_folds(series_uids, seed=1337, folds=4):
    """Match D-Persona's patient ordering, seeded shuffle and four-fold split."""
    groups = {}
    for index, uid in enumerate(series_uids):
        groups.setdefault(str(uid).split("_")[0], []).append(index)
    patients = list(groups)
    np.random.RandomState(seed).shuffle(patients)
    result = []
    for test_positions in np.array_split(np.arange(len(patients)), folds):
        test_positions = set(test_positions.tolist())
        train_patients = [p for i, p in enumerate(patients) if i not in test_positions]
        test_patients = [p for i, p in enumerate(patients) if i in test_positions]
        result.append({
            "train_patients": train_patients,
            "test_patients": test_patients,
            "train_indices": [i for p in train_patients for i in groups[p]],
            "test_indices": [i for p in test_patients for i in groups[p]],
        })
    return result


def source_folds(series_uids):
    """The released run_train splits shuffled slice indices, not patients."""
    from sklearn.model_selection import KFold

    indices = list(range(len(series_uids)))
    np.random.RandomState(1337).shuffle(indices)
    result = []
    for train, test in KFold(n_splits=4, shuffle=False).split(indices):
        train_indices = [indices[i] for i in train]
        test_indices = [indices[i] for i in test]
        train_patients = sorted({str(series_uids[i]).split("_")[0] for i in train_indices})
        test_patients = sorted({str(series_uids[i]).split("_")[0] for i in test_indices})
        result.append({
            "train_indices": train_indices, "test_indices": test_indices,
            "train_patients": train_patients, "test_patients": test_patients,
            "overlapping_patients": sorted(set(train_patients) & set(test_patients)),
        })
    return result


def datasets_for_run(data_root, name, stage, fold, seed, released_source=False, lidc_split=None):
    root = Path(data_root)
    if name == "lidc":
        path = root / "lidc_attributes.pkl"
        train = lidc.LIDC_IDRI(stage, str(path), transform=lidc.transform)
        test = lidc.Test_LIDC(stage, str(path), transform=lidc.batch_transform)
        split_kind = lidc_split or ("slice" if released_source else "patient")
        if split_kind not in ("slice", "patient"):
            raise ValueError(f"Unknown LIDC split: {split_kind}")
        split = (source_folds(train.series_uid) if split_kind == "slice"
                 else patient_folds(train.series_uid, seed))[fold]
        if split_kind == "patient":
            assert not set(split["train_patients"]) & set(split["test_patients"])
        metadata = {"dataset": name, "fold": fold,
                    "evaluation_split": "held_out_slices" if split_kind == "slice" else "held_out_patients", **split}
        return Subset(train, split["train_indices"]), Subset(test, split["test_indices"]), metadata
    if name == "npc":
        path = root / "MMIS2024TASK1"
        train = npc_170.NPC_170(stage, str(path), split="train", transform=npc_170.transform)
        # The supplied public archive contains validation labels, but no test labels.
        test = npc_170.Test_NPC_3D(stage, str(path), split="val", transform=npc_170.batch_transform)
        if not released_source:
            train.sample_list.sort()
        test.sample_list.sort()
        metadata = {
            "dataset": name, "fold": None, "evaluation_split": "validation",
            "train_files": train.sample_list, "evaluation_files": test.sample_list,
            "formal_test_status": "unavailable: official test images and labels/evaluation required",
        }
        return train, test, metadata
    raise ValueError(f"Unknown dataset: {name}")
