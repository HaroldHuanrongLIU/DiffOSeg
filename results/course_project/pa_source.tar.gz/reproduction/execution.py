"""Execution changes that preserve batches, RNG consumption and update formulas."""
import hashlib
from pathlib import Path

import torch
from torch.utils.data import Sampler

from datasets import npc_170
from ddpm.trainer import Trainer


def cache_npc_raw(dataset):
    """Cache only decoded inputs; keep every stochastic transform in the caller."""
    cache = [npc_170.BaseDataSet.__getitem__(dataset, i) for i in range(len(dataset))]
    dataset._raw_cache = cache
    return sum(item["image"].nbytes + item["label"].nbytes for item in cache)


class StatefulSampler(Sampler):
    """Remember the original sampler's permutation without drawing extra RNG."""
    def __init__(self, sampler):
        self.sampler = sampler
        self.order = None
        self.position = 0
        self.resuming = False

    def __len__(self):
        return len(self.sampler)

    def __iter__(self):
        if self.resuming:
            self.resuming = False
        else:
            self.order = list(self.sampler)
            self.position = 0
        while self.position < len(self.order):
            index = self.order[self.position]
            self.position += 1
            yield index

    def state_dict(self):
        return {"order": list(self.order), "position": self.position}

    def load_state_dict(self, state):
        expected = getattr(self.sampler, "indices", range(len(self.sampler)))
        if sorted(state["order"]) != sorted(expected):
            raise ValueError("Saved sampler indices differ from the training split")
        if not 0 <= state["position"] <= len(self.sampler):
            raise ValueError("Invalid saved sampler position")
        self.order = list(state["order"])
        self.position = state["position"]
        self.resuming = True


class ExecutionTrainer(Trainer):
    def _check_loss(self, loss, context):
        # Same three predicates; synchronize once on the healthy path.
        invalid = (torch.isnan(loss).any() | torch.isinf(loss).any()
                   | (loss.sum(dim=1) < -1e-3).any())
        if bool(invalid):
            super()._check_loss(loss, context)


def prepare_debug_directory(output):
    """Retain original np.save calls while avoiding per-step HDD writes."""
    path = Path(output) / "visual_debug"
    name = hashlib.sha256(str(Path(output).resolve()).encode()).hexdigest()[:16]
    target = Path("/dev/shm") / f"diffoseg-debug-{name}"
    target.mkdir(exist_ok=True)
    if not path.is_symlink():
        if path.exists():
            raise ValueError("Optimized execution needs a fresh debug directory")
        path.symlink_to(target, target_is_directory=True)
    if path.resolve() != target:
        raise ValueError("Unexpected debug directory target")
    return target
