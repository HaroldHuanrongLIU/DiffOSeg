"""Execution optimizations and exact sample-budget accounting."""
import math

import torch
from torch.utils.data import Sampler

from ddpm.polyak import PolyakAverager


class ForeachEMA(PolyakAverager):
    def __init__(self, model, average, alpha):
        super().__init__(model, average, alpha)
        self.groups = {}
        self.integer_buffers = []
        if self.polyak_enabled:
            targets = average.state_dict()
            for name, source in model.state_dict().items():
                target = targets[name]
                if source.is_floating_point():
                    sources, destinations = self.groups.setdefault((source.device, source.dtype), ([], []))
                    sources.append(source)
                    destinations.append(target)
                else:
                    self.integer_buffers.append((source, target))

    @torch.no_grad()
    def update(self):
        for sources, targets in self.groups.values():
            scaled = torch._foreach_mul(sources, 1 - self.alpha)
            torch._foreach_mul_(targets, self.alpha)
            torch._foreach_add_(targets, scaled)
        for source, target in self.integer_buffers:
            # Preserve the original averager's cast semantics for counters.
            target.copy_(self.alpha * target + (1 - self.alpha) * source)


def reference_sample_budget(size, batch_size, steps):
    epochs, remainder = divmod(steps, math.ceil(size / batch_size))
    return epochs * size + min(remainder * batch_size, size)


class ContinuousBatchSampler(Sampler):
    """Full batches across epoch boundaries, with an exact final sample count."""
    def __init__(self, size, batch_size, samples, seed, start=0):
        self.size, self.batch_size, self.samples = size, batch_size, samples
        self.seed, self.start = seed, start

    def __len__(self):
        return math.ceil((self.samples - self.start) / self.batch_size)

    def __iter__(self):
        epoch, offset = divmod(self.start, self.size)
        remaining = self.samples - self.start
        batch = []
        while remaining:
            order = torch.randperm(self.size, generator=torch.Generator().manual_seed(self.seed + epoch)).tolist()
            while offset < self.size and remaining:
                count = min(self.batch_size - len(batch), self.size - offset, remaining)
                batch.extend(order[offset:offset + count])
                offset += count
                remaining -= count
                if len(batch) == self.batch_size or not remaining:
                    yield batch
                    batch = []
            epoch += 1
            offset = 0
